export const bsca = {
    emailAddress: 'mqtest50@chpmail.com',
    organization: 'BSCA',
    screenName: 'bsca',
    userType: '4',
    carrierID: '957',
};