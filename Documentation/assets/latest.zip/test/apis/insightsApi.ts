import { Logger } from '@nestjs/common';
import _ from 'lodash';
import rp from 'request-promise';

export class InsightsApi {
    protected readonly logger = new Logger('InsightsApi');

    constructor(
        readonly baseURL: string,
        readonly jwt: string,) { }

    _populate(input: string | object, props: object | undefined) {
        if (!props) return input;
        const org = _.isString(input) ? input : JSON.stringify(input);
        const output = Object.keys(props).reduce((p, c) => {
            const v = p.replace(new RegExp(`\{${c}\}`, 'g'), props[c]);
            return v;
        }, org);
        return _.isString(input) ? output : JSON.parse(output);
    }

    request(api: string, props = {}, payload = {}) {
        const [method, uri] = api.split(' ');
        const req = {
            uri: this.baseURL + this._populate(uri, props),
            method,
            json: true,
            ...this._populate(payload, props),
            headers: {
                Authorization: `Bearer ${this.jwt}`,
            }
        };
        this.logger.debug({ req });
        return rp(req);
    }
}