import { Logger } from '@nestjs/common';
import { InsightsApi } from './insightsApi';


const ENDPOINTS = {
    queryData_AonHhvi3icPPO: 'GET /consultantBenchmarking/queryData?consultant=Aon&uploadCode=1021201907&reportCategory=hhvi&networkType=ppo&reportType=3ic',
    queryData_AonHhvi3icPOS: 'GET /consultantBenchmarking/queryData?consultant=Aon&uploadCode=1021201907&reportCategory=hhvi&networkType=pos&reportType=3ic',
    queryData_AonHhvi3ttPPO: 'GET /consultantBenchmarking/queryData?consultant=Aon&uploadCode=1021201907&reportCategory=hhvi&networkType=ppo&reportType=3tt',
    queryData_AonHhvi3ttPOS: 'GET /consultantBenchmarking/queryData?consultant=Aon&uploadCode=1021201907&reportCategory=hhvi&networkType=pos&reportType=3tt',
    queryData_AonHhvi5icPPO: 'GET /consultantBenchmarking/queryData?consultant=Aon&uploadCode=1021201907&reportCategory=hhvi&networkType=ppo&reportType=5ic',
    queryData_AonHhvi5icPOS: 'GET /consultantBenchmarking/queryData?consultant=Aon&uploadCode=1021201907&reportCategory=hhvi&networkType=pos&reportType=5ic',
    queryData_AonVqeTotalPPO: 'GET /consultantBenchmarking/queryData?consultant=Aon&uploadCode=1021201907&reportCategory=valuequest&networkType=ppo&reportType=total',
};

export class ConsultantBenchmarkingApi extends InsightsApi {
    protected readonly logger = new Logger('ConsultantBenchmarkingApi');

    async queryData_AonHhvi3icPPO() {
        const resp = await this.request(ENDPOINTS.queryData_AonHhvi3icPPO);
        return resp;
    }

    async queryData_AonHhvi3icPOS() {
        const resp = await this.request(ENDPOINTS.queryData_AonHhvi3icPOS);
        return resp;
    }

    async queryData_AonHhvi3ttPPO() {
        const resp = await this.request(ENDPOINTS.queryData_AonHhvi3ttPPO);
        return resp;
    }

    async queryData_AonHhvi3ttPOS() {
        const resp = await this.request(ENDPOINTS.queryData_AonHhvi3ttPOS);
        return resp;
    }

    async queryData_AonHhvi5icPPO() {
        const resp = await this.request(ENDPOINTS.queryData_AonHhvi5icPPO);
        return resp;
    }

    async queryData_AonHhvi5icPOS() {
        const resp = await this.request(ENDPOINTS.queryData_AonHhvi5icPOS);
        return resp;
    }

    async queryData_AonVqeTotalPPO() {
        const resp = await this.request(ENDPOINTS.queryData_AonVqeTotalPPO);
        return resp;
    }

}