import { INestApplication, Logger } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import os from 'os';
import { AppModule } from '../src/app.module';
import { Identity } from '../src/identity/identity.model';
import { IdentityModule } from '../src/identity/identity.module';
import { IdentityService } from '../src/identity/identity.service';
import { config } from '../src/main';
import { CarrierRestriction } from '../src/security/orm/carrierRestriction.entity.ms';
import { SecurityModule } from '../src/security/security.module';
import { SecurityService } from '../src/security/security.service';
import { ConsultantBenchmarkingApi } from './apis/consultantBenchmarkingApi';
import { bsca } from './fixtures/identities';


describe('Insights Services e2e Testing....', () => {
  const logger = new Logger('app.e2e-spec');
  let app: INestApplication;
  let baseURL: string;
  let jwt: string;

  // ===========Services=========== //
  let identityService: IdentityService;
  let securityService: SecurityService;

  // ===========APIs=========== //
  let consultantBenchmarkingApi: ConsultantBenchmarkingApi;

  beforeAll(async () => {
    config();
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
    app = moduleFixture.createNestApplication();
    await app.init();


    identityService = app.select(IdentityModule).get(IdentityService, { strict: true });
    securityService = app.select(SecurityModule).get(SecurityService, { strict: true });
    // baseURL = app.getHttpServer();
    jwt = identityService.encodeJWT(bsca);

    baseURL = `http://${os.hostname()}:${process.env.PORT}${process.env.PUBLIC_URL}`;
    consultantBenchmarkingApi = new ConsultantBenchmarkingApi(baseURL, jwt);
  });

  describe('Module | IdentityModule', () => {
    it('Get Token of "bsca", the decoded identity shall contains same payloads', () => {
      const identity: Identity = identityService.decodeJWT(jwt);
      expect(identity.screenName).toBe(bsca.screenName);
    });
  });

  describe('Module | ConsultantBenchmarkingModule', () => {
    it('queryData_AonHhvi3icPPO returns not null Data', async () => {
      const response = await consultantBenchmarkingApi.queryData_AonHhvi3icPPO();
      const restrictions: CarrierRestriction[] = await securityService.getRestrictRules(bsca);
      logger.debug({ restrictions });
      expect(response.length > 0).toBe(true);
    });
    it('queryData_AonHhvi3icPOS returns not null Data', async () => {
      const response = await consultantBenchmarkingApi.queryData_AonHhvi3icPOS();
      expect(response.length > 0).toBe(true);
    });
    it('queryData_AonHhvi3ttPPO returns not null Data', async () => {
      const response = await consultantBenchmarkingApi.queryData_AonHhvi3ttPPO();
      expect(response.length > 0).toBe(true);
    });
    it('queryData_AonHhvi3ttPOS returns not null Data', async () => {
      const response = await consultantBenchmarkingApi.queryData_AonHhvi3ttPOS();
      expect(response.length > 0).toBe(true);
    });
    it('queryData_AonHhvi5icPPO returns not null Data', async () => {
      const response = await consultantBenchmarkingApi.queryData_AonHhvi5icPPO();
      expect(response.length > 0).toBe(true);
    });
    it('queryData_AonHhvi5icPOS returns not null Data', async () => {
      const response = await consultantBenchmarkingApi.queryData_AonHhvi5icPOS();
      expect(response.length > 0).toBe(true);
    });
    it('queryData_AonVqeTotalPPO returns not null Data', async () => {
      const response = await consultantBenchmarkingApi.queryData_AonVqeTotalPPO();
      expect(response.length > 0).toBe(true);
    });
  });

  afterAll(async () => {
    await app.close();
    return true;
  });


});


