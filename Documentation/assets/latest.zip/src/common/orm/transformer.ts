import { isEmpty, split, toNumber, toString, trim } from 'lodash';
import { ValueTransformer } from 'typeorm';

export class StringNumberTransformer implements ValueTransformer {
    to = (value: string): number => toNumber(value);
    from = (value: number): string => toString(value);
}

export class NumberStringTransformer implements ValueTransformer {
    from = (value: string): number => toNumber(value);
    to = (value: number): string => toString(value);
}

export class ArrayStringTransformer<T extends string | number> implements ValueTransformer {
    to(arry: T[]): string {
        return isEmpty
            (arry) ? '' : arry.join(',');
    }

    from(arrString: any): T[] {
        return isEmpty(arrString) ? [] : split(trim(arrString), ',') as T[];
    }
}
