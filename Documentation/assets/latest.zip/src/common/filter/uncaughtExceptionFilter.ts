import { ArgumentsHost, Catch, ExceptionFilter, HttpException, Logger } from '@nestjs/common';
import { BaseExceptionFilter } from '@nestjs/core';
import { GqlArgumentsHost, GqlExceptionFilter } from '@nestjs/graphql';
import { Request, Response } from 'express';
import { GraphQLResolveInfo } from 'graphql';



const INSIGHTS_SERVICE_ERRORS = {
    'error': 'auth-0001',
    'message': 'Incorrect username and password',
    'detail': 'Ensure that the username and password included in the request are correct',
    'help': 'https://example.com/help/error/auth-0001'
};


@Catch(Error)
export class UncaughtExceptionFilter extends BaseExceptionFilter implements ExceptionFilter, GqlExceptionFilter {
    catch(error: Error, host: ArgumentsHost) {
        if (error instanceof HttpException)
            return super.catch(error, host);
        Logger.error(error);
        const ctx = host.switchToHttp();
        const response = ctx.getResponse<Response>();
        const request = ctx.getRequest<Request>();
        const gqlHost = GqlArgumentsHost.create(host);
        const info = gqlHost.getInfo<GraphQLResolveInfo>();
    }
}
