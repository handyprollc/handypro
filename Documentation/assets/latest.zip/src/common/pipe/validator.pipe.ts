import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import Ajv from 'ajv';
import _ from 'lodash';
@Injectable()
export class Validator implements PipeTransform {
  private readonly ajv: Ajv.Ajv = new Ajv({
    $data: true,
    removeAdditional: true,
    extendRefs: true,
  });

  constructor(
    private readonly schema: object,
    private readonly optional: boolean = false,
  ) { }

  async transform(value: any, metadata: ArgumentMetadata) {
    if (this.optional && _.isEmpty(value)) return value;
    const { data, type } = metadata;
    if (!this.ajv.validateSchema(this.schema))
      throw new Error(`Invalid JSON schema!:${this.schema}`);
    const validate = this.ajv.compile(this.schema);
    const valid = validate(value);
    if (!valid) {
      const { message, params } = validate.errors[0];
      throw new BadRequestException(`${type}[${data}] ${message}! ${JSON.stringify(params)}`);
    }
    return value;
  }
}
