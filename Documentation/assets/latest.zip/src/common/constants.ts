export const MSSQL = 'MSSQL';
// export const POSTGRES = 'database.postgres';
export const PG_DM = 'PG_DM';
export const PG_DATAMART = 'PG_DATAMART';
export const PG_FDM = 'PG_FDM';

export const DB_IDS = 'IDSDev';
export const DB_BENCHMARKING = 'Benchmarking_Dev';
export const DB_SALESAPP = 'SalesApp';

