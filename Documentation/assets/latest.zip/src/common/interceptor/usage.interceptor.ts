import { EmployerService } from '@app/employer/employer.service';
import { Identity } from '@app/identity/identity.model';
import { IdentityService } from '@app/identity/identity.service';
import { CallHandler, ExecutionContext, Inject, Injectable, NestInterceptor } from '@nestjs/common';
import { GqlExecutionContext } from '@nestjs/graphql';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class EmployerSearchUsageInterceptor implements NestInterceptor {
    constructor(
        @Inject(IdentityService) private readonly identityService: IdentityService,
        @Inject(EmployerService) private readonly employerService: EmployerService,
    ) { }
    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
        console.log('Before...');

        const now = Date.now();
        return next
            .handle()
            .pipe(
                tap(async () => {
                    const gqlCtx = GqlExecutionContext.create(context);
                    const params = gqlCtx.getArgs();
                    const { req } = await gqlCtx.getContext();
                    const { screenName } = this.identityService.identify(req);
                    this.employerService.logUsage(screenName, params);
                }),
            );
    }
}
