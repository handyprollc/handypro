import { TabularData } from './tabularData';
import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class MetadataResponse {
    @Field()
    metadata: Object;
    @Field()
    data: TabularData;
}