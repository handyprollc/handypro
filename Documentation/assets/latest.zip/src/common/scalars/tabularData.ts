import { Field, ObjectType } from '@nestjs/graphql';
import _ from 'lodash';
@ObjectType()
export class TabularData<Entity = any>  {
    @Field({ nullable: true })
    length: number = 0;
    @Field(type => [String], { nullable: true })
    columns: (keyof Entity)[] = [];
    @Field(type => [String], { nullable: true })
    rows: any[] = [];
    constructor(vals: Entity[], view?: (keyof Entity)[]) {
        if (!_.isEmpty(vals)) {
            this.length = vals.length;
            this.columns = view || (Object.keys(vals[0]) as (keyof Entity)[]);
            this.rows = vals.map(r => this.columns.map(c => r[c]));
        }
    }
}