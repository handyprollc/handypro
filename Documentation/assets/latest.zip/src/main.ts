import { AppModule } from '@app/app.module';
import { Logger, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import bodyParser from 'body-parser';
import * as dotenv from 'dotenv';
import { express as voyagerMiddleware } from 'graphql-voyager/middleware';
import * as os from 'os';
import { join, resolve } from 'path';

const logger = new Logger('Main', true);

export function config() {
  const appName = require(join(process.cwd(), 'package.json')).name;
  const nodeEnvPath = resolve(process.env.NODE_ENV_PATH, `${appName}.env`);
  dotenv.config({ path: nodeEnvPath });
  logger.debug(`Configuration : ${nodeEnvPath}`);
}
declare const module: any;

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: process.env.NODE_ENV === 'development' ? ['log', 'debug', 'error', 'verbose', 'warn'] : ['error', 'warn'],
  });

  const port = process.env.PORT || 3000;
  const gqlUri = process.env.URI_GRAPHQL || '/graphql';
  const voyagerUri = process.env.URI_VOYAGER || '/voyager';
  app.use(bodyParser({ limit: '50MB' }));
  app.enableCors();
  app.setGlobalPrefix(process.env.PUBLIC_URL);
  app.useGlobalPipes(new ValidationPipe());
  // const { httpAdapter } = app.get(HttpAdapterHost);
  // app.useGlobalFilters(new UncaughtExceptionFilter(httpAdapter));
  app.use(voyagerUri, voyagerMiddleware({ endpointUrl: gqlUri }));
  await app.listen(port, () => {
    logger.log(`🚀 Graphql is listening on: http://${os.hostname}:${port}${gqlUri}`);
    logger.log(`🚀 Voyager is listening on: http://${os.hostname}:${port}${voyagerUri}`);
  });

  if (module.hot) {
    module.hot.accept();
    module.hot.dispose(() => app.close());
  }

}
config();
bootstrap();
