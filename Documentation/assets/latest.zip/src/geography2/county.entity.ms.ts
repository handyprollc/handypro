import { DB_BENCHMARKING } from '@app/common/constants';
import { State } from '@app/geography2/state.entity.ms';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('GEO_County2')
@Entity('counties', { database: DB_BENCHMARKING, schema: 'geography' })
export class County {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
    @Field(type => State, { nullable: true })
    @ManyToOne(type => State, { lazy: true })
    @JoinColumn({ name: 'state' })
    state: State;
}
