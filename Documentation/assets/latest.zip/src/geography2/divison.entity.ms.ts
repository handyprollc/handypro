import { DB_BENCHMARKING } from '@app/common/constants';
import { Region } from '@app/geography2/region.entity.ms';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';

@ObjectType('GEO_Division2')
@Entity('divisions', { database: DB_BENCHMARKING, schema: 'geography' })
export class Division {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
    @Field(type => Region, { nullable: true })
    @ManyToOne(type => Region, { lazy: true })
    @JoinColumn({ name: 'region' })
    region: Region;
}
