import { DB_BENCHMARKING } from '@app/common/constants';
import { Division } from '@app/geography2/divison.entity.ms';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('GEO_State2')
@Entity('states', { database: DB_BENCHMARKING, schema: 'geography' })
export class State {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
    @Field({ nullable: true })
    @Column()
    abbreviation: string;
    @Field({ nullable: true })
    @Column({ name: 'division' })
    divisionId: number;
    @Field(type => Division, { nullable: true })
    @ManyToOne(type => Division, divison => divison.id, { lazy: true })
    @JoinColumn({ name: 'division' })
    division: Division;
}
