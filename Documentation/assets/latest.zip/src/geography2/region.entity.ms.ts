import { DB_BENCHMARKING } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('GEO_Region2')
@Entity('regions', { database: DB_BENCHMARKING, schema: 'geography' })
export class Region {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
}
