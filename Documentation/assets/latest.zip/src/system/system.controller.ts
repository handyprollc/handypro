import { Controller, Get, Render, Res } from '@nestjs/common';
import { resolve } from 'path';

@Controller('system')
export class SystemController {
    @Get('schema.gql')
    schema(@Res() res) {
        res.sendFile(resolve(__dirname + '../../../schema.gql'));
    }
}
