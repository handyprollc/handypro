import { DB_SALESAPP } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { CompanyExecutives } from './company-executives.entity.ms';

@ObjectType()
@Entity({ database: DB_SALESAPP, schema: 'sao' })
export class Company {
  @Field()
  @PrimaryGeneratedColumn('uuid')
  readonly id: string;
  @Field({ nullable: true })
  @Column()
  providerCompanyId: string;
  @Field({ nullable: true })
  @Column()
  yearLoad: string;
  @Field({ nullable: true })
  @Column()
  dunsNumber: string;
  @Field({ nullable: true })
  @Column()
  stakeholderCode: string;
  @Field({ nullable: true })
  @Column()
  companyName: string;
  @Field({ nullable: true })
  @Column()
  streetAddress: string;
  @Field({ nullable: true })
  @Column()
  city: string;
  @Field({ nullable: true })
  @Column()
  stateAbbreviation: string;
  @Field({ nullable: true })
  @Column()
  postalCode: string;
  @Field({ nullable: true })
  @Column()
  webSite: string;
  @Field({ nullable: true })
  @Column()
  stockSymbol: string;
  @Field({ nullable: true })
  @Column({ name: 'fortune_1000_rank' })
  fortune1000Rank: number;
  @Field({ nullable: true })
  @Column()
  chpIndustryCode: string;
  @Field({ nullable: true })
  @Column()
  domesticUltimateName: string;
  @Field({ nullable: true })
  @Column()
  naicsNationalIndustry: string;
  @Field({ nullable: true })
  @Column()
  employeesTotal: number;
  @Field({ nullable: true })
  @Column()
  decisionMakerCode: string;
  @Field({ nullable: true })
  @Column()
  sourceId: string;
  @Field(type => Date, { nullable: true })
  @Column({ type: 'datetime' })
  createDate: string;
  @Field(type => Date, { nullable: true })
  @Column({ type: 'datetime' })
  updateDate: Date;
  @Field(type => [CompanyExecutives], { nullable: true })
  @OneToMany(type => CompanyExecutives, p => p.company, { lazy: true })
  personnels: CompanyExecutives[];
}
