import { MSSQL } from '@app/common/constants';
import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Company } from './company.entity.ms';

@Injectable()
export class CompanyService {
  protected readonly logger = new Logger('CompanyResolver');

  constructor(
    @InjectRepository(Company, MSSQL)
    private readonly companyRepository: Repository<Company>,
  ) { }

  async query(name: string, benefitSponsor: boolean): Promise<Company[]> {
    this.logger.log(
      `Query companies with - name: ${name}, benefitSponsor: ${benefitSponsor}`,
    );
    const qb = this.companyRepository
      .createQueryBuilder('c')
      .where(`c.companyName like '%${name}%'`)
      .orderBy('c.decisionMakerCode', 'DESC')
      .take(200);
    if (undefined !== benefitSponsor && benefitSponsor) {
      qb.andWhere(`c.decisionMakerCode = 'D'`);
    }
    return await qb.getMany();
  }
}
