import { Controller, Get, Logger, Query as Qry } from '@nestjs/common';
import { Args, Query, Resolver } from '@nestjs/graphql';
import { Company } from './company.entity.ms';
import { CompanyService } from './company.service';

@Resolver('company')
@Controller('company')
export class CompanyResolver {
  protected readonly logger = new Logger('CompanyResolver');

  constructor(private readonly companyService: CompanyService) { }

  @Get()
  @Query(returns => [Company], { name: 'company_companies' })
  companies(
    @Args('name')
    name: string,
    @Args('benefitSponsor')
    benefitSponsor: boolean = false,
    @Qry('name')
    name2: string,
    @Qry('benefitSponsor')
    benefitSponsor2: boolean = false,
  ): Promise<Company[]> {
    return this.companyService.query(
      name || name2,
      benefitSponsor || benefitSponsor2,
    );
  }
}
