import { DB_SALESAPP } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Company } from './company.entity.ms';

@ObjectType()
@Entity({ database: DB_SALESAPP, schema: 'sao' })
export class CompanyExecutives {
    @PrimaryGeneratedColumn('uuid')
    readonly id: string;
    @Field({ nullable: true })
    @Column()
    prefix: string;
    @Field({ nullable: true })
    @Column()
    firstName: string;
    @Field({ nullable: true })
    @Column()
    middleInitial: string;
    @Field({ nullable: true })
    @Column()
    lastName: string;
    @Field({ nullable: true })
    @Column()
    suffix: string;
    @Field({ nullable: true })
    @Column()
    title: string;
    @Field(type => Company, { nullable: true })
    @ManyToOne(type => Company, { lazy: true })
    @JoinColumn({ name: 'company_id' })
    company: Company;

}
