import { MSSQL } from '@app/common/constants';
import { Injectable, Logger } from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import _ from 'lodash';
import { EntityManager } from 'typeorm';
import { AonHhvi3icPOS } from './orm/aonHhvi3icPOS.entity.ms';
import { AonHhvi3icPPO } from './orm/aonHhvi3icPPO.entity.ms';
import { AonHhvi3ttPOS } from './orm/aonHhvi3ttPOS.entity.ms';
import { AonHhvi3ttPPO } from './orm/aonHhvi3ttPPO.entity.ms';
import { AonHhvi5icPOS } from './orm/aonHhvi5icPOS.entity.ms';
import { AonHhvi5icPPO } from './orm/aonHhvi5icPPO.entity.ms';
import { AonParticipatingPlan } from './orm/aonParticipatingPlan.entity.ms';
import { AonVqeIcPOS } from './orm/aonVqeIcPOS.entity.ms';
import { AonVqeIcPPO } from './orm/aonVqeIcPPO.entity.ms';
import { AonVqeTotalPOS } from './orm/aonVqeTotalPOS.entity.ms';
import { AonVqeTotalPPO } from './orm/aonVqeTotalPPO.entity.ms';

// type AonData = AonHhvi3icPOS
//   | AonHhvi3icPPO
//   | AonHhvi3ttPOS
//   | AonHhvi3ttPPO
//   | AonHhvi5icPOS
//   | AonHhvi5icPPO
//   | AonVqeIcPOS
//   | AonVqeIcPPO
//   | AonVqeTotalPOS
//   | AonVqeTotalPPO;

type KEYS = (
  keyof AonHhvi3icPOS
  | keyof AonHhvi3icPPO
  | keyof AonHhvi3ttPOS
  | keyof AonHhvi3ttPPO
  | keyof AonHhvi5icPOS
  | keyof AonHhvi5icPPO
  | keyof AonVqeIcPOS
  | keyof AonVqeIcPPO
  | keyof AonVqeTotalPOS
  | keyof AonVqeTotalPPO
);

const BLIND_KEYS: KEYS[] = ['hewittName', 'nationalNetwork', 'networkType'];

const HHVI_COMPETITOR_CALCULATION = {
  competitorAverage: { measure: 'planDiscountAll', factor: 'claimsVolumeFlagAll', count: 0, total: 0 },
  inNetworkCompetitorAverageIp: { measure: 'planDiscountIp', factor: 'claimsVolumeFlagIp', count: 0, total: 0 },
  inNetworkCompetitorAverageOp: { measure: 'planDiscountOp', factor: 'claimsVolumeFlagOp', count: 0, total: 0 },
  inNetworkCompetitorAveragePro: { measure: 'planDiscountPro', factor: 'claimsVolumeFlagPro', count: 0, total: 0 },
  inNetworkCompetitorAverageLab: { measure: 'planDiscountLab', factor: 'claimsVolumeFlagLab', count: 0, total: 0 },
  inNetworkCompetitorAverageRad: { measure: 'planDiscountRad', factor: 'claimsVolumeFlagRad', count: 0, total: 0 },
  totalOonCompetitorAverage: { measure: 'totalOonDiscount', factor: 'claimsVolumeFlagAll', count: 0, total: 0 },
};

const VQE_COMPETITOR_CALCULATION = {
  totalNetworkCompetitorAverage: { measure: 'totalNetworkDiscount', factor: 'claimsVolumeFlagAll', count: 0, total: 0 },
  caTotalInpatientFacility: { measure: 'tndTotalInpatientFacility', factor: 'viTotalInpatientFacility', count: 0, total: 0 },
  caInpatientMaternity: { measure: 'tndInpatientMedicalSurgical', factor: 'viInpatientMedicalSurgical', count: 0, total: 0 },
  caInpatientMedicalSurgical: { measure: 'tndInpatientMaternity', factor: 'viInpatientMaternity', count: 0, total: 0 },
  caInpatientOther: { measure: 'tndInpatientOther', factor: 'viInpatientOther', count: 0, total: 0 },
  caTotalOutpatientFacility: { measure: 'tndTotalOutpatientFacility', factor: 'viTotalOutpatientFacility', count: 0, total: 0 },
  caEmergencyRoom: { measure: 'tndEmergencyRoom', factor: 'viEmergencyRoom', count: 0, total: 0 },
  caOutpatientSurgery: { measure: 'tndOutpatientSurgery', factor: 'viOutpatientSurgery', count: 0, total: 0 },
  caOutpatientRadiology: { measure: 'tndOutpatientRadiology', factor: 'viOutpatientRadiology', count: 0, total: 0 },
  caOutpatientPathology: { measure: 'tndOutpatientPathology', factor: 'viOutpatientPathology', count: 0, total: 0 },
  caOtherOutpatientFacilityServices: { measure: 'tndOtherOutpatientFacilityServices', factor: 'viOtherOutpatientFacilityServices', count: 0, total: 0 },
  caTotalProfessional: { measure: 'tndTotalProfessional', factor: 'viTotalProfessional', count: 0, total: 0 },
  caSurgery: { measure: 'tndSurgery', factor: 'viSurgery', count: 0, total: 0 },
  caOfficeHomevisits: { measure: 'tndOfficeHomeVisits', factor: 'viOfficeHomevisits', count: 0, total: 0 },
  caPreventativeServices: { measure: 'tndPreventativeServices', factor: 'viPreventativeServices', count: 0, total: 0 },
  caRadiology: { measure: 'tndRadiology', factor: 'viRadiology', count: 0, total: 0 },
  caPathology: { measure: 'tndPathology', factor: 'viPathology', count: 0, total: 0 },
  caOtherProfessionalServices: { measure: 'tndOtherProfessionalServices', factor: 'viOtherProfessionalServices', count: 0, total: 0 },
};

@Injectable()
export class AonBenchmarkingService {

  protected readonly logger = new Logger('AonBenchmarkingService');

  constructor(
    @InjectEntityManager(MSSQL)
    private readonly em: EntityManager,
  ) { }

  async queryAonHhvi3icPPO(
    criteria: Partial<AonHhvi3icPPO>,
    restrictedCarriers?: string[]): Promise<AonHhvi3icPPO[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonHhvi3icPPO;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonHhvi3icPPO).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        planDiscountAll: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, HHVI_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonHhvi3ttPPO(
    criteria: Partial<AonHhvi3ttPPO>,
    restrictedCarriers?: string[]): Promise<Partial<AonHhvi3ttPPO>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonHhvi3ttPPO;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonHhvi3ttPPO).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        planDiscountAll: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, HHVI_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonHhvi3icPOS(
    criteria: Partial<AonHhvi3icPOS>,
    restrictedCarriers?: string[]): Promise<Partial<AonHhvi3icPOS>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonHhvi3icPOS;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonHhvi3icPOS).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        planDiscountAll: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, HHVI_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonHhvi3ttPOS(
    criteria: Partial<AonHhvi3ttPOS>,
    restrictedCarriers?: string[]): Promise<Partial<AonHhvi3ttPOS>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonHhvi3ttPOS;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonHhvi3ttPOS).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        planDiscountAll: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, HHVI_COMPETITOR_CALCULATION);
    return recalculated;
  }
  async queryAonHhvi5icPPO(
    criteria: Partial<AonHhvi5icPPO>,
    restrictedCarriers?: string[]): Promise<Partial<AonHhvi5icPPO>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonHhvi5icPPO;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonHhvi5icPPO).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        planDiscountAll: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, HHVI_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonHhvi5icPOS(
    criteria: Partial<AonHhvi5icPOS>,
    restrictedCarriers?: string[]): Promise<Partial<AonHhvi5icPOS>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonHhvi5icPOS;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonHhvi5icPOS).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        planDiscountAll: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, HHVI_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonVqeTotalPPO(
    criteria: Partial<AonVqeTotalPPO>,
    restrictedCarriers?: string[]): Promise<Partial<AonVqeTotalPPO>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonVqeTotalPPO;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonVqeTotalPPO).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        totalNetworkDiscount: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, VQE_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonVqeTotalPOS(
    criteria: Partial<AonVqeTotalPOS>,
    restrictedCarriers?: string[]): Promise<Partial<AonVqeTotalPOS>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonVqeTotalPOS;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonVqeTotalPOS).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        totalNetworkDiscount: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, VQE_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonVqeIcPOS(
    criteria: Partial<AonVqeIcPOS>,
    restrictedCarriers?: string[]): Promise<Partial<AonVqeIcPOS>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonVqeIcPOS;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonVqeIcPOS).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        totalNetworkDiscount: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, VQE_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryAonVqeIcPPO(
    criteria: Partial<AonVqeIcPPO>,
    restrictedCarriers?: string[]): Promise<Partial<AonVqeIcPPO>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = AonVqeIcPPO;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(AonVqeIcPPO).find({
      select,
      where: criteria,
      order: {
        state: 'ASC',
        hewittMarketName: 'ASC',
        totalNetworkDiscount: 'DESC',
      },
    });
    const blinded = this.blind(rows, BLIND_KEYS, restrictedCarriers);
    const recalculated = this.calculateCompetitorData(blinded, VQE_COMPETITOR_CALCULATION);
    return recalculated;
  }

  async queryParticipatingPlans(uploadCode: number): Promise<AonParticipatingPlan[]> {
    return this.em.getRepository(AonParticipatingPlan).find({
      where: { uploadCode },
      order: {
        blueVsCompetitorFlag: 'ASC',
        carrierName: 'ASC',
        networkType: 'ASC',
        networkName: 'ASC',
      },
    });
  }

  private isCompetitorRow(row: { hewittName?: string, networkType?: string, carrier?: string, }) {
    return (_.has(row, 'networkType') && _.isEmpty(row.networkType))
      || (_.has(row, 'hewittName') && (_.isEmpty(row.hewittName) || _.includes(['unknown'], _.toLower(row.hewittName))))
      || (_.has(row, 'carrier') && _.isEmpty(row.carrier));
  }


  private calculateCompetitorData(rows: any[], competitorCalculation: object) {
    if (_.isEmpty(rows)) return [];
    const grouped = _.groupBy(rows, it => `${it.state}_${it.hewittMarketName}`);
    const competitorDataKeys = _.intersection(_.keys(rows[0]), _.keys(competitorCalculation));
    const res = [];
    Object.keys(grouped).forEach(k => {
      const marketRows = grouped[k];
      const calc = _.cloneDeep(_.pick(competitorCalculation, competitorDataKeys));
      for (const row of marketRows.filter(r => this.isCompetitorRow(r))) {
        // const values = _.pick(row, competitorDataKeys);
        // const factor = _.pick(row, )
        for (const key of competitorDataKeys) {
          const calItm = calc[key];
          const factor = _.get(row, `${calItm.factor}`);
          const value = _.get(row, `${calItm.measure}`);
          this.logger.debug(`${k} : ${key}:${value}@${factor}`);
          if (factor !== '<1%') {
            calItm.total += value;
            calItm.count += 1;
            this.logger.debug(`${k} : ${key}[${calItm.count}]:${value}\t(${calItm.total}/${calItm.count}=${calItm.total / calItm.count})`);
          }
        }
      }
      this.logger.debug(`${k} - ${JSON.stringify(calc)}`);
      for (const row of marketRows) {
        for (const key of competitorDataKeys) {
          row[key] = _.round(calc[key].total / calc[key].count, 3);
        }
      }

      res.push(...marketRows);
    });
    return res;
  }

  private blind(
    rows: any[],
    blindedKeys?: string[],
    restrictedCarriers?: string[]) {
    if (_.isEmpty(rows)) return [];
    restrictedCarriers = _.uniq(restrictedCarriers);
    if (_.isEmpty(blindedKeys)) {
      const blinded = rows.find(r => this.isCompetitorRow(r));
      blindedKeys = Object.keys(blinded).filter(k => !_.isNumber(blinded[k]) && _.isEmpty(blinded[k]));
    } else {
      blindedKeys = _.intersection(blindedKeys, _.keys(rows[0]));
    }
    return rows.map(r => {
      const res = { ...r };
      if (_.toLower(r.nationalNetwork) === 'bluecard tpv') {
        let chg: boolean;
        chg = _.has(res, 'planClaimsAll') && _.set(res, 'planClaimsAll', 0);
        chg = _.has(res, 'planClaimsIp') && _.set(res, 'planClaimsIp', 0);
        chg = _.has(res, 'planClaimsOp') && _.set(res, 'planClaimsOp', 0);
        chg = _.has(res, 'planClaimsPro') && _.set(res, 'planClaimsPro', 0);
        chg = _.has(res, 'planClaimsLab') && _.set(res, 'planClaimsLab', 0);
        chg = _.has(res, 'planClaimsRad') && _.set(res, 'planClaimsRad', 0);
      }
      if (restrictedCarriers.includes(r.carrierCode)) {
        for (const key of blindedKeys) {
          if (_.has(res, key))
            res[key] = null;
        }
      }
      // delete res.carrierCode;
      return res;
    });
  }
}
