import { AonBenchmarkingService } from '@app/consultantBenchmarking/aonBenchmarking.service';
import { ConsultantBenchmarkingResolver } from '@app/consultantBenchmarking/consultantBenchmarking.resolver';
import { IdentityModule } from '@app/identity/identity.module';
import { SecurityModule } from '@app/security/security.module';
import { Module } from '@nestjs/common';
import { ConsultantBenchmarkingService } from './consultantBenchmarking.service';
import { MercerBenchmarkingService } from './mercerBenchmarking.service';


@Module({
  imports: [SecurityModule, IdentityModule],
  providers: [ConsultantBenchmarkingResolver, AonBenchmarkingService, ConsultantBenchmarkingService, MercerBenchmarkingService],
  exports: [AonBenchmarkingService, ConsultantBenchmarkingService, MercerBenchmarkingService],
  controllers: [ConsultantBenchmarkingResolver]
})
export class ConsultantBenchmarkingModule { }
