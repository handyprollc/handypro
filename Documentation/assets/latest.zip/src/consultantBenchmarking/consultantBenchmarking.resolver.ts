import { Validator } from '@app/common/pipe/validator.pipe';
import { TabularData } from '@app/common/scalars/tabularData';
import { Identity } from '@app/identity/identity.model';
import { IdentityService } from '@app/identity/identity.service';
import { AuthGuard } from '@app/security/auth.guard';
import { SecurityService } from '@app/security/security.service';
import { BadRequestException, Controller, Get, Logger, Param, ParseIntPipe, Query as Qry, Req, UseGuards } from '@nestjs/common';
import { Args, Query, Resolver } from '@nestjs/graphql';
import { Request } from 'express';
import { AonBenchmarkingService } from './aonBenchmarking.service';
import { ConsultantBenchmarkingService } from './consultantBenchmarking.service';
import { MercerBenchmarkingService } from './mercerBenchmarking.service';
import { AonHhvi3icPOS } from './orm/aonHhvi3icPOS.entity.ms';
import { AonHhvi3icPPO } from './orm/aonHhvi3icPPO.entity.ms';
import { AonHhvi3ttPOS } from './orm/aonHhvi3ttPOS.entity.ms';
import { AonHhvi3ttPPO } from './orm/aonHhvi3ttPPO.entity.ms';
import { AonHhvi5icPOS } from './orm/aonHhvi5icPOS.entity.ms';
import { AonHhvi5icPPO } from './orm/aonHhvi5icPPO.entity.ms';
import { AonParticipatingPlan } from './orm/aonParticipatingPlan.entity.ms';
import { AonVqeIcPOS } from './orm/aonVqeIcPOS.entity.ms';
import { AonVqeIcPPO } from './orm/aonVqeIcPPO.entity.ms';
import { AonVqeTotalPOS } from './orm/aonVqeTotalPOS.entity.ms';
import { AonVqeTotalPPO } from './orm/aonVqeTotalPPO.entity.ms';
import { DataUpload, DataUploadCritera } from './orm/dataUpload.entity.ms';
import { MercerPMPMCompeting } from './orm/mercerPMPMCompeting.entity.ms';
import { MercerPMPMNonCompeting } from './orm/mercerPMPMNonCompeting.entity.ms';

const ConsultantOptions = ['Aon', 'Mercer'];
@Controller('consultantBenchmarking')
@Resolver('consultantBenchmarking')
export class ConsultantBenchmarkingResolver {
  protected readonly logger = new Logger('ConsultantBenchmarkingResolver');

  constructor(
    private readonly aonBenchmarkingService: AonBenchmarkingService,
    private readonly consultantBenchmarkingService: ConsultantBenchmarkingService,
    private readonly mercerBenchmarkingService: MercerBenchmarkingService,
    private readonly securityService: SecurityService,
    private readonly identityService: IdentityService,
  ) { }


  @Get('getAonParticipatingPlans/:uploadCode')
  async getAonParticipatingPlans(
    @Param(
      'uploadCode',
      new ParseIntPipe(),
      new Validator({ type: 'integer', minLength: 1 })
    ) uploadCode: number): Promise<TabularData> {
    const results = await this.aonBenchmarkingService.queryParticipatingPlans(uploadCode);
    return new TabularData(
      results.map(({ carrierName, networkName, reportSpecificNetworkType }) => ({ carrierName, networkName, reportSpecificNetworkType }))
    );
  }

  @Query(returns => [DataUpload], { name: 'consultantBenchmarking_DataUploads' })
  @UseGuards(AuthGuard)
  async queryDataUploads(
    @Args({ name: 'criteria', type: () => DataUploadCritera })
    criteria: Partial<DataUploadCritera>
  ): Promise<DataUpload[]> {
    return this.consultantBenchmarkingService.queryDataUploads(criteria);
  }

  @Query(returns => [AonParticipatingPlan], { name: 'consultantBenchmarking_AonParticipatingPlans' })
  @UseGuards(AuthGuard)
  async queryAonParticipatingPlans(
    @Args({ name: 'uploadCode', type: () => Number })
    uploadCode: number
  ): Promise<AonParticipatingPlan[]> {
    return this.aonBenchmarkingService.queryParticipatingPlans(uploadCode);
  }

  @Get('queryData')
  @Query(returns => TabularData, { name: 'consultantBenchmarking_queryData' })
  @UseGuards(AuthGuard)
  async queryData(
    @Req() req: Request,
    @Qry('consultant', new Validator({ type: 'string', enum: ConsultantOptions, minLength: 1 }))
    consultant: string,
    @Qry('uploadCode', new Validator({ type: 'string', minLength: 1 }))
    uploadCode: string,
    @Qry('reportCategory', new Validator({ type: 'string', enum: ['hhvi', 'valuequest', 'pmpm'], minLength: 1 }))
    reportCategory: string,
    @Qry('reportType', new Validator({ type: 'string', enum: ['3tt', '3ic', '5ic', 'ic', 'total', 'results', 'competing', 'nonCompeting'], minLength: 1 }))
    reportType: string,
    @Qry('networkType', new Validator({ type: 'string', enum: ['ppo', 'pos'] }, true))
    networkType?: string,
  ): Promise<TabularData> {
    const restrictions = await this.securityService.getRestrictRulesFromRequest(req);
    const identity: Identity = this.identityService.identify(req);
    const restrictedCarrierCodes = restrictions.map(r => r.restrictedCarrierCode);
    let results = [];
    if (consultant === 'Aon'
      && reportCategory === 'hhvi'
      && networkType === 'ppo'
      && reportType === '3ic') {
      results = await this.aonBenchmarkingService.queryAonHhvi3icPPO({
        uploadCode,
      }, restrictedCarrierCodes);
      return new TabularData(results, AonHhvi3icPPO.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Aon'
      && reportCategory === 'hhvi'
      && networkType === 'ppo'
      && reportType === '3tt') {
      results = await this.aonBenchmarkingService.queryAonHhvi3ttPPO({
        uploadCode,
      }, restrictedCarrierCodes);
      return new TabularData(results, AonHhvi3ttPPO.DISPLAY_COLUMNS);
    } else if (consultant === 'Aon'
      && reportCategory === 'hhvi'
      && networkType === 'ppo'
      && reportType === '5ic') {
      results = await this.aonBenchmarkingService.queryAonHhvi5icPPO({
        uploadCode,
      }, restrictedCarrierCodes);
      return new TabularData(results, AonHhvi5icPPO.DISPLAY_COLUMNS);
    } else if (consultant === 'Aon'
      && reportCategory === 'hhvi'
      && networkType === 'pos'
      && reportType === '3ic') {
      results = await this.aonBenchmarkingService.queryAonHhvi3icPOS({
        uploadCode,
      }, restrictedCarrierCodes);
      return new TabularData(results, AonHhvi3icPOS.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Aon'
      && reportCategory === 'hhvi'
      && networkType === 'pos'
      && reportType === '3tt') {
      results = await this.aonBenchmarkingService.queryAonHhvi3ttPOS({
        uploadCode,
      }, restrictedCarrierCodes);
      return new TabularData(results, AonHhvi3ttPOS.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Aon'
      && reportCategory === 'hhvi'
      && networkType === 'pos'
      && reportType === '5ic') {
      results = await this.aonBenchmarkingService.queryAonHhvi5icPOS({
        uploadCode,
      }, restrictedCarrierCodes);
      return new TabularData(results, AonHhvi5icPOS.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Aon'
      && reportCategory === 'valuequest'
      && networkType === 'ppo'
      && reportType === 'total') {
      results = await this.aonBenchmarkingService.queryAonVqeTotalPPO({
        uploadCode
      }, restrictedCarrierCodes);
      return new TabularData(results, AonVqeTotalPPO.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Aon'
      && reportCategory === 'valuequest'
      && networkType === 'pos'
      && reportType === 'total') {
      results = await this.aonBenchmarkingService.queryAonVqeTotalPOS({
        uploadCode
      }, restrictedCarrierCodes);
      return new TabularData(results, AonVqeTotalPOS.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Aon'
      && reportCategory === 'valuequest'
      && networkType === 'ppo'
      && reportType === 'ic') {
      results = await this.aonBenchmarkingService.queryAonVqeIcPPO({
        uploadCode
      }, restrictedCarrierCodes);
      return new TabularData(results, AonVqeIcPPO.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Aon'
      && reportCategory === 'valuequest'
      && networkType === 'pos'
      && reportType === 'ic') {
      results = await this.aonBenchmarkingService.queryAonVqeIcPOS({
        uploadCode
      }, restrictedCarrierCodes);
      return new TabularData(results, AonVqeIcPOS.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Mercer'
      && reportCategory === 'pmpm'
      && reportType === 'competing') {
      results = await this.mercerBenchmarkingService.queryMercerPMPMCompeting({ uploadCode }, identity);
      return new TabularData(results, MercerPMPMCompeting.DISPLAY_COLUMNS);
    }
    else if (consultant === 'Mercer'
      && reportCategory === 'pmpm'
      && reportType === 'nonCompeting') {
      results = await this.mercerBenchmarkingService.queryMercerPMPMNonCompeting({ uploadCode }, identity);
      return new TabularData(results, MercerPMPMNonCompeting.DISPLAY_COLUMNS);
    }
    throw new BadRequestException(`Bad request!: ${JSON.stringify({
      consultant,
      uploadCode,
      reportCategory,
      reportType,
      networkType,
    })}`);
  }
}
