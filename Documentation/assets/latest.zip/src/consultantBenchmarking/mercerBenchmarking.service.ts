import { MSSQL } from '@app/common/constants';
import { Identity } from '@app/identity/identity.model';
import { Injectable, Logger } from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import { includes, isEmpty } from 'lodash';
import { EntityManager } from 'typeorm';
import { MercerPMPMCompeting } from './orm/mercerPMPMCompeting.entity.ms';
import { MercerPMPMNonCompeting } from './orm/mercerPMPMNonCompeting.entity.ms';

type KEYS = (keyof MercerPMPMCompeting | MercerPMPMNonCompeting);
const BLIND_KEYS: KEYS[] = ['carrier'];
@Injectable()
export class MercerBenchmarkingService {

  protected readonly logger = new Logger('MercerBenchmarkingService');

  constructor(
    @InjectEntityManager(MSSQL)
    private readonly em: EntityManager,
  ) { }

  async queryMercerPMPMCompeting(
    criteria: Partial<MercerPMPMCompeting>
    , identity: Identity): Promise<Partial<MercerPMPMCompeting>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = MercerPMPMCompeting;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(MercerPMPMCompeting).find({
      select,
      where: criteria,
      order: {
        selectedAreas: 'ASC',
        sortOrder: 'ASC',
      },
    });
    const blinded = this.blind(rows, identity);
    return blinded;
  }

  async queryMercerPMPMNonCompeting(
    criteria: Partial<MercerPMPMNonCompeting>,
    identity: Identity): Promise<Partial<MercerPMPMNonCompeting>[]> {
    const { DISPLAY_COLUMNS, METADATA_COLUMNS } = MercerPMPMNonCompeting;
    const select = [...DISPLAY_COLUMNS, ...METADATA_COLUMNS];
    const rows = await this.em.getRepository(MercerPMPMNonCompeting).find({
      select,
      where: criteria,
      order: {
        selectedAreas: 'ASC',
        sortOrder: 'ASC',
      },
    });
    const blinded = this.blind(rows, identity);
    return blinded;
  }


  private blind(
    rows: (MercerPMPMCompeting | MercerPMPMNonCompeting)[],
    identity: Identity) {
    if (isEmpty(rows)) return [];
    const { carrierID: currentCarrierId } = identity;
    return rows.map(r => {
      const { blindedCarrierId, carrierId } = r;
      if (currentCarrierId !== carrierId && includes(blindedCarrierId, currentCarrierId))
        r.carrier = null;
      return r;
    });
  }
}
