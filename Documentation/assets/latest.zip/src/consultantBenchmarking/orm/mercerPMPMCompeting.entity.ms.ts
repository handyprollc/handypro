import { DB_BENCHMARKING } from '@app/common/constants';
import { NumberStringTransformer, StringNumberTransformer } from '@app/common/orm/transformer';
import { Column, Entity, PrimaryColumn } from 'typeorm';

/*Results - Competing*/
@Entity('vw_dm_mercer_pmpm_competiting_area', { database: DB_BENCHMARKING, schema: 'Benchmarking_App' })
export class MercerPMPMCompeting {

    @PrimaryColumn({ name: 'report_name' }) reportName: string;
    @PrimaryColumn({ name: 'selected_areas' }) selectedAreas: string;
    @PrimaryColumn({ name: 'carrier' }) carrier: string;
    @PrimaryColumn({ name: 'netpic_2.0_relativity_score' }) netPic_2_0RelativityScore: number;
    @PrimaryColumn({ name: 'risk_score' }) riskScore: number;
    @PrimaryColumn({ name: 'mercer_risk_score_carrier median' }) mercerRiskScoreCarrierMedian: number;
    @PrimaryColumn({ name: 'membership', transformer: new NumberStringTransformer() }) membership: number;
    @PrimaryColumn({ name: 'upload_code' }) uploadCode: string;
    @PrimaryColumn({ name: 'carrier_id', transformer: new StringNumberTransformer() }) carrierId: string;
    @PrimaryColumn({ name: 'pdr_product_id' }) pdrProductId: string;
    @PrimaryColumn({ name: 'mercer_market_code' }) mercerMarketCode: string;
    @PrimaryColumn({ name: 'sequence_number' }) sequenceNumber: number;
    @PrimaryColumn({ name: 'type_of_calculation' }) typeOfCalculation: string;
    @PrimaryColumn({ name: 'batchseq' }) batchseq: number;
    @PrimaryColumn({ name: 'pdr_priority_flag' }) pdrPriorityFlag: number;
    @Column({ name: 'blended_carrier_id', type: 'simple-array' }) blindedCarrierId: string[];
    @PrimaryColumn({ name: 'blended_product_code' }) blindedProductCode: string;
    @PrimaryColumn({ name: 'sort_order' }) sortOrder: number;

    static readonly METADATA_COLUMNS: (keyof MercerPMPMCompeting)[] = [
        'carrierId', 'sortOrder', 'blindedCarrierId'
    ];

    static readonly DISPLAY_COLUMNS: (keyof MercerPMPMCompeting)[] = [
        'selectedAreas',
        'carrier',
        'netPic_2_0RelativityScore',
        'riskScore',
        'mercerRiskScoreCarrierMedian',
        'membership',
    ];
}