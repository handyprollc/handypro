import { DB_BENCHMARKING } from '@app/common/constants';
import _ from 'lodash';
import { Entity, PrimaryColumn, ValueTransformer } from 'typeorm';

const transformer: ValueTransformer = {
    to: (val: object) => _.isArray(val) ? val[0] : _.toNumber(val),
    from: (val: number) => _.isArray(val) ? val[0] : _.toNumber(val),
};
/*
IC (PPO-ValueQuest)
*/
@Entity('vw_dm_vqe_3ic_ppo', { database: DB_BENCHMARKING, schema: 'Benchmarking_App' })
export class AonVqeIcPPO {
    @PrimaryColumn({ name: 'chp_product_type_name' }) chpProductTypeName: string;
    @PrimaryColumn({ name: 'report_type' }) reportType: string;
    @PrimaryColumn({ name: 'carrier_code' }) carrierCode: string;
    @PrimaryColumn({ name: 'product_code' }) productCode: string;
    @PrimaryColumn({ name: 'upload_code' }) uploadCode: string;
    @PrimaryColumn({ name: 'upload_name' }) uploadName: string;
    @PrimaryColumn({ name: 'state' }) state: string;
    @PrimaryColumn({ name: 'hewitt_market_name' }) hewittMarketName: string;
    @PrimaryColumn({ name: 'hewitt_name' }) hewittName: string;
    @PrimaryColumn({ name: 'network_type' }) networkType: string;
    @PrimaryColumn({ name: 'total_network_discount' }) totalNetworkDiscount: number;
    @PrimaryColumn({ name: 'total_network_competitor_average' }) totalNetworkCompetitorAverage: number;
    @PrimaryColumn({ name: 'your_claims' }) yourClaims: number;
    @PrimaryColumn({ name: 'comparative_groups_total' }) comparativeGroupsTotal: number;
    @PrimaryColumn({ name: 'share_of_comparative_groups' }) shareOfComparativeGroups: number;
    @PrimaryColumn({ name: 'claims_volume_flag_all' }) claimsVolumeFlagAll: number;
    @PrimaryColumn({ name: 'tnd_total_inpatient_facility' }) tndTotalInpatientFacility: number;
    @PrimaryColumn({ name: 'tnd_inpatient_maternity' }) tndInpatientMaternity: number;
    @PrimaryColumn({ name: 'tnd_inpatient_medical_surgical' }) tndInpatientMedicalSurgical: number;
    @PrimaryColumn({ name: 'tnd_inpatient_other' }) tndInpatientOther: number;
    @PrimaryColumn({ name: 'tnd_total_outpatient_facility' }) tndTotalOutpatientFacility: number;
    @PrimaryColumn({ name: 'tnd_emergency_room' }) tndEmergencyRoom: number;
    @PrimaryColumn({ name: 'tnd_outpatient_surgery' }) tndOutpatientSurgery: number;
    @PrimaryColumn({ name: 'tnd_outpatient_radiology' }) tndOutpatientRadiology: number;
    @PrimaryColumn({ name: 'tnd_outpatient_pathology' }) tndOutpatientPathology: number;
    @PrimaryColumn({ name: 'tnd_other_outpatient_facility_services' }) tndOtherOutpatientFacilityServices: number;
    @PrimaryColumn({ name: 'tnd_total_professional' }) tndTotalProfessional: number;
    @PrimaryColumn({ name: 'tnd_surgery' }) tndSurgery: number;
    @PrimaryColumn({ name: 'tnd_office_home_visits' }) tndOfficeHomeVisits: number;
    @PrimaryColumn({ name: 'tnd_preventative_services' }) tndPreventativeServices: number;
    @PrimaryColumn({ name: 'tnd_radiology' }) tndRadiology: number;
    @PrimaryColumn({ name: 'tnd_pathology' }) tndPathology: number;
    @PrimaryColumn({ name: 'tnd_other_professional_services' }) tndOtherProfessionalServices: number;
    @PrimaryColumn({ name: 'ca_total_inpatient_facility' }) caTotalInpatientFacility: number;
    @PrimaryColumn({ name: 'ca_inpatient_maternity' }) caInpatientMaternity: number;
    @PrimaryColumn({ name: 'ca_inpatient_medical_surgical' }) caInpatientMedicalSurgical: number;
    @PrimaryColumn({ name: 'ca_inpatient_other' }) caInpatientOther: number;
    @PrimaryColumn({ name: 'ca_total_outpatient_facility' }) caTotalOutpatientFacility: number;
    @PrimaryColumn({ name: 'ca_emergency_room' }) caEmergencyRoom: number;
    @PrimaryColumn({ name: 'ca_outpatient_surgery' }) caOutpatientSurgery: number;
    @PrimaryColumn({ name: 'ca_outpatient_radiology' }) caOutpatientRadiology: number;
    @PrimaryColumn({ name: 'ca_outpatient_pathology' }) caOutpatientPathology: number;
    @PrimaryColumn({ name: 'ca_other_outpatient_facility_services' }) caOtherOutpatientFacilityServices: number;
    @PrimaryColumn({ name: 'ca_total_professional' }) caTotalProfessional: number;
    @PrimaryColumn({ name: 'ca_surgery' }) caSurgery: number;
    @PrimaryColumn({ name: 'ca_office_homevisits' }) caOfficeHomevisits: number;
    @PrimaryColumn({ name: 'ca_preventative_services' }) caPreventativeServices: number;
    @PrimaryColumn({ name: 'ca_radiology' }) caRadiology: number;
    @PrimaryColumn({ name: 'ca_pathology' }) caPathology: number;
    @PrimaryColumn({ name: 'ca_other_professional_services' }) caOtherProfessionalServices: number;
    @PrimaryColumn({ name: 'yc_total_inpatient_facility' }) ycTotalInpatientFacility: number;
    @PrimaryColumn({ name: 'yc_inpatient_maternity' }) ycInpatientMaternity: number;
    @PrimaryColumn({ name: 'yc_inpatient_medical_surgical' }) ycInpatientMedicalSurgical: number;
    @PrimaryColumn({ name: 'yc_inpatient_other' }) ycInpatientOther: number;
    @PrimaryColumn({ name: 'yc_total_outpatient_facility' }) ycTotalOutpatientFacility: number;
    @PrimaryColumn({ name: 'yc_emergency_room' }) ycEmergencyRoom: number;
    @PrimaryColumn({ name: 'yc_outpatient_surgery' }) ycOutpatientSurgery: number;
    @PrimaryColumn({ name: 'yc_outpatient_radiology' }) ycOutpatientRadiology: number;
    @PrimaryColumn({ name: 'yc_outpatient_pathology' }) ycOutpatientPathology: number;
    @PrimaryColumn({ name: 'yc_other_outpatient_facility_services' }) ycOtherOutpatientFacilityServices: number;
    @PrimaryColumn({ name: 'yc_total_professional' }) ycTotalProfessional: number;
    @PrimaryColumn({ name: 'yc_surgery' }) ycSurgery: number;
    @PrimaryColumn({ name: 'yc_office_homevisits' }) ycOfficeHomevisits: number;
    @PrimaryColumn({ name: 'yc_preventative_services' }) ycPreventativeServices: number;
    @PrimaryColumn({ name: 'yc_radiology' }) ycRadiology: number;
    @PrimaryColumn({ name: 'yc_pathology' }) ycPathology: number;
    @PrimaryColumn({ name: 'yc_other_professional_services' }) ycOtherProfessionalServices: number;
    @PrimaryColumn({ name: 'cgt_total_inpatient_facility' }) cgtTotalInpatientFacility: number;
    @PrimaryColumn({ name: 'cgt_inpatient_maternity' }) cgtInpatientMaternity: number;
    @PrimaryColumn({ name: 'cgt_inpatient_medical_surgical' }) cgtInpatientMedicalSurgical: number;
    @PrimaryColumn({ name: 'cgt_inpatient_other' }) cgtInpatientOther: number;
    @PrimaryColumn({ name: 'cgt_total_outpatient_facility' }) cgtTotalOutpatientFacility: number;
    @PrimaryColumn({ name: 'cgt_emergency_room' }) cgtEmergencyRoom: number;
    @PrimaryColumn({ name: 'cgt_outpatient_surgery' }) cgtOutpatientSurgery: number;
    @PrimaryColumn({ name: 'cgt_outpatient_radiology' }) cgtOutpatientRadiology: number;
    @PrimaryColumn({ name: 'cgt_outpatient_pathology' }) cgtOutpatientPathology: number;
    @PrimaryColumn({ name: 'cgt_other_outpatient_facility_services' }) cgtOtherOutpatientFacilityServices: number;
    @PrimaryColumn({ name: 'cgt_total_professional' }) cgtTotalProfessional: number;
    @PrimaryColumn({ name: 'cgt_surgery' }) cgtSurgery: number;
    @PrimaryColumn({ name: 'cgt_office_home_visits' }) cgtOfficeHomeVisits: number;
    @PrimaryColumn({ name: 'cgt_preventative_services' }) cgtPreventativeServices: number;
    @PrimaryColumn({ name: 'cgt_radiology' }) cgtRadiology: number;
    @PrimaryColumn({ name: 'cgt_pathology' }) cgtPathology: number;
    @PrimaryColumn({ name: 'cgt_other_professional_services' }) cgtOtherProfessionalServices: number;
    @PrimaryColumn({ name: 'scg_total_inpatient_facility' }) scgTotalInpatientFacility: number;
    @PrimaryColumn({ name: 'scg_inpatient_maternity' }) scgInpatientMaternity: number;
    @PrimaryColumn({ name: 'scg_inpatient_medical_surgical' }) scgInpatientMedicalSurgical: number;
    @PrimaryColumn({ name: 'scg_inpatient_other' }) scgInpatientOther: number;
    @PrimaryColumn({ name: 'scg_total_outpatient_facility' }) scgTotalOutpatientFacility: number;
    @PrimaryColumn({ name: 'scg_emergency_room' }) scgEmergencyRoom: number;
    @PrimaryColumn({ name: 'scg_outpatient_surgery' }) scgOutpatientSurgery: number;
    @PrimaryColumn({ name: 'scg_outpatient_radiology' }) scgOutpatientRadiology: number;
    @PrimaryColumn({ name: 'scg_outpatient_pathology' }) scgOutpatientPathology: number;
    @PrimaryColumn({ name: 'scg_other_outpatient_facility_services' }) scgOtherOutpatientFacilityServices: number;
    @PrimaryColumn({ name: 'scg_total_professional' }) scgTotalProfessional: number;
    @PrimaryColumn({ name: 'scg_surgery' }) scgSurgery: number;
    @PrimaryColumn({ name: 'scg_office_homevisits' }) scgOfficeHomevisits: number;
    @PrimaryColumn({ name: 'scg_preventative_services' }) scgPreventativeServices: number;
    @PrimaryColumn({ name: 'scg_radiology' }) scgRadiology: number;
    @PrimaryColumn({ name: 'scg_pathology' }) scgPathology: number;
    @PrimaryColumn({ name: 'scg_other_professional_services' }) scgOtherProfessionalServices: number;
    @PrimaryColumn({ name: 'vi_total_inpatient_facility' }) viTotalInpatientFacility: string;
    @PrimaryColumn({ name: 'vi_inpatient_maternity' }) viInpatientMaternity: string;
    @PrimaryColumn({ name: 'vi_inpatient_medical_surgical' }) viInpatientMedicalSurgical: string;
    @PrimaryColumn({ name: 'vi_inpatient_other' }) viInpatientOther: string;
    @PrimaryColumn({ name: 'vi_total_outpatient_facility' }) viTotalOutpatientFacility: string;
    @PrimaryColumn({ name: 'vi_emergency_room' }) viEmergencyRoom: string;
    @PrimaryColumn({ name: 'vi_outpatient_surgery' }) viOutpatientSurgery: string;
    @PrimaryColumn({ name: 'vi_outpatient_radiology' }) viOutpatientRadiology: string;
    @PrimaryColumn({ name: 'vi_outpatient_pathology' }) viOutpatientPathology: string;
    @PrimaryColumn({ name: 'vi_other_outpatient_facility_services' }) viOtherOutpatientFacilityServices: string;
    @PrimaryColumn({ name: 'vi_total_professional' }) viTotalProfessional: string;
    @PrimaryColumn({ name: 'vi_surgery' }) viSurgery: string;
    @PrimaryColumn({ name: 'vi_office_homevisits' }) viOfficeHomevisits: string;
    @PrimaryColumn({ name: 'vi_preventative_services' }) viPreventativeServices: string;
    @PrimaryColumn({ name: 'vi_radiology' }) viRadiology: string;
    @PrimaryColumn({ name: 'vi_pathology' }) viPathology: string;
    @PrimaryColumn({ name: 'vi_other_professional_services' }) viOtherProfessionalServices: string;

    static readonly METADATA_COLUMNS: (keyof AonVqeIcPPO)[] = [
        'carrierCode',
    ];

    static DISPLAY_COLUMNS: (keyof AonVqeIcPPO)[] = [
        'state',
        'hewittMarketName',
        'hewittName',
        'networkType',
        'totalNetworkDiscount',
        'totalNetworkCompetitorAverage',
        'yourClaims',
        'comparativeGroupsTotal',
        'shareOfComparativeGroups',
        'claimsVolumeFlagAll',
        'tndTotalInpatientFacility',
        'tndInpatientMaternity',
        'tndInpatientMedicalSurgical',
        'tndInpatientOther',
        'tndTotalOutpatientFacility',
        'tndEmergencyRoom',
        'tndOutpatientSurgery',
        'tndOutpatientRadiology',
        'tndOutpatientPathology',
        'tndOtherOutpatientFacilityServices',
        'tndTotalProfessional',
        'tndSurgery',
        'tndOfficeHomeVisits',
        'tndPreventativeServices',
        'tndRadiology',
        'tndPathology',
        'tndOtherProfessionalServices',
        'caTotalInpatientFacility',
        'caInpatientMaternity',
        'caInpatientMedicalSurgical',
        'caInpatientOther',
        'caTotalOutpatientFacility',
        'caEmergencyRoom',
        'caOutpatientSurgery',
        'caOutpatientRadiology',
        'caOutpatientPathology',
        'caOtherOutpatientFacilityServices',
        'caTotalProfessional',
        'caSurgery',
        'caOfficeHomevisits',
        'caPreventativeServices',
        'caRadiology',
        'caPathology',
        'caOtherProfessionalServices',
        'ycTotalInpatientFacility',
        'ycInpatientMaternity',
        'ycInpatientMedicalSurgical',
        'ycInpatientOther',
        'ycTotalOutpatientFacility',
        'ycEmergencyRoom',
        'ycOutpatientSurgery',
        'ycOutpatientRadiology',
        'ycOutpatientPathology',
        'ycOtherOutpatientFacilityServices',
        'ycTotalProfessional',
        'ycSurgery',
        'ycOfficeHomevisits',
        'ycPreventativeServices',
        'ycRadiology',
        'ycPathology',
        'ycOtherProfessionalServices',
        'cgtTotalInpatientFacility',
        'cgtInpatientMaternity',
        'cgtInpatientMedicalSurgical',
        'cgtInpatientOther',
        'cgtTotalOutpatientFacility',
        'cgtEmergencyRoom',
        'cgtOutpatientSurgery',
        'cgtOutpatientRadiology',
        'cgtOutpatientPathology',
        'cgtOtherOutpatientFacilityServices',
        'cgtTotalProfessional',
        'cgtSurgery',
        'cgtOfficeHomeVisits',
        'cgtPreventativeServices',
        'cgtRadiology',
        'cgtPathology',
        'cgtOtherProfessionalServices',
        'scgTotalInpatientFacility',
        'scgInpatientMaternity',
        'scgInpatientMedicalSurgical',
        'scgInpatientOther',
        'scgTotalOutpatientFacility',
        'scgEmergencyRoom',
        'scgOutpatientSurgery',
        'scgOutpatientRadiology',
        'scgOutpatientPathology',
        'scgOtherOutpatientFacilityServices',
        'scgTotalProfessional',
        'scgSurgery',
        'scgOfficeHomevisits',
        'scgPreventativeServices',
        'scgRadiology',
        'scgPathology',
        'scgOtherProfessionalServices',
        'viTotalInpatientFacility',
        'viInpatientMaternity',
        'viInpatientMedicalSurgical',
        'viInpatientOther',
        'viTotalOutpatientFacility',
        'viEmergencyRoom',
        'viOutpatientSurgery',
        'viOutpatientRadiology',
        'viOutpatientPathology',
        'viOtherOutpatientFacilityServices',
        'viTotalProfessional',
        'viSurgery',
        'viOfficeHomevisits',
        'viPreventativeServices',
        'viRadiology',
        'viPathology',
        'viOtherProfessionalServices',
    ];
}
