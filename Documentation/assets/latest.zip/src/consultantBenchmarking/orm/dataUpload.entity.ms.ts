import { DB_BENCHMARKING } from '@app/common/constants';
import { Field, InputType, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryColumn } from 'typeorm';


@ObjectType()
@Entity('vw_benchmarking_upload', { database: DB_BENCHMARKING, schema: 'Benchmarking_App' })
export class DataUpload {
    @Field({ nullable: true }) @PrimaryColumn() readonly uploadCode: string;
    @Field({ nullable: true }) @Column() readonly consultant: string;
    @Field({ nullable: true }) @Column() readonly year: string;
    @Field({ nullable: true }) @Column() readonly upload: string;
    @Field({ nullable: true }) @Column() readonly uploadName: string;
    @Field({ nullable: true }) @Column() readonly incurredStart: string;
    @Field({ nullable: true }) @Column() readonly incurredEnd: string;
    @Field({ nullable: true }) @Column() readonly paidThrough: string;
}

@InputType()
export class DataUploadCritera {
    @Field({ nullable: true }) readonly uploadCode: string;
    @Field({ nullable: true }) readonly consultant: string;
    @Field({ nullable: true }) readonly year: string;
    @Field({ nullable: true }) readonly upload: string;
    @Field({ nullable: true }) readonly uploadName: string;
    @Field({ nullable: true }) readonly incurredStart: string;
    @Field({ nullable: true }) readonly incurredEnd: string;
    @Field({ nullable: true }) readonly paidThrough: string;
}
