import { DB_BENCHMARKING } from '@app/common/constants';
import { Entity, PrimaryColumn } from 'typeorm';

/*
IC (POS-HHVI-5Cat)
*/
@Entity('vw_dm_hhvi_5ic_pos', { database: DB_BENCHMARKING, schema: 'Benchmarking_App' })
export class AonHhvi5icPOS {
    @PrimaryColumn() carrierCode: string;
    @PrimaryColumn() readonly state: string;
    @PrimaryColumn() readonly hewittMarketName: string;
    @PrimaryColumn() readonly hewittName: string;
    @PrimaryColumn() readonly nationalNetwork: string;
    @PrimaryColumn() readonly chpProductTypeName: string;
    @PrimaryColumn() readonly planDiscountAll: number;
    @PrimaryColumn() readonly totalOonDiscount: number;
    @PrimaryColumn() readonly competitorAverage: number;
    @PrimaryColumn() readonly totalOonCompetitorAverage: number;
    @PrimaryColumn() readonly planClaimsAll: number;
    @PrimaryColumn() readonly marketClaimsAll: number;
    @PrimaryColumn() readonly claimsShareAll: number;
    @PrimaryColumn() readonly claimsVolumeFlagAll: string;
    @PrimaryColumn() readonly planDiscountIp: number;
    @PrimaryColumn() readonly planDiscountOp: number;
    @PrimaryColumn() readonly planDiscountPro: number;
    @PrimaryColumn() readonly planDiscountLab: number;
    @PrimaryColumn() readonly planDiscountRad: number;
    @PrimaryColumn() readonly inNetworkCompetitorAverageIp: number;
    @PrimaryColumn() readonly inNetworkCompetitorAverageOp: number;
    @PrimaryColumn() readonly inNetworkCompetitorAveragePro: number;
    @PrimaryColumn() readonly inNetworkCompetitorAverageLab: number;
    @PrimaryColumn() readonly inNetworkCompetitorAverageRad: number;
    @PrimaryColumn() readonly planClaimsIp: number;
    @PrimaryColumn() readonly planClaimsOp: number;
    @PrimaryColumn() readonly planClaimsPro: number;
    @PrimaryColumn() readonly planClaimsLab: number;
    @PrimaryColumn() readonly planClaimsRad: number;
    @PrimaryColumn() readonly marketClaimsIp: number;
    @PrimaryColumn() readonly marketClaimsOp: number;
    @PrimaryColumn() readonly marketClaimsPro: number;
    @PrimaryColumn() readonly marketClaimsLab: number;
    @PrimaryColumn() readonly marketClaimsRad: number;
    @PrimaryColumn() readonly claimsShareIp: number;
    @PrimaryColumn() readonly claimsShareOp: number;
    @PrimaryColumn() readonly claimsSharePro: number;
    @PrimaryColumn() readonly claimsShareLab: number;
    @PrimaryColumn() readonly claimsShareRad: number;
    @PrimaryColumn() readonly claimsVolumeFlagIp: string;
    @PrimaryColumn() readonly claimsVolumeFlagOp: string;
    @PrimaryColumn() readonly claimsVolumeFlagPro: string;
    @PrimaryColumn() readonly claimsVolumeFlagLab: string;
    @PrimaryColumn() readonly claimsVolumeFlagRad: string;
    @PrimaryColumn() readonly discountRank: number;
    @PrimaryColumn() readonly uploadCode: string;
    @PrimaryColumn() readonly reportType: string;
    @PrimaryColumn() readonly batchId: number;

    static readonly METADATA_COLUMNS: (keyof AonHhvi5icPOS)[] = [
        'carrierCode',
    ];

    static readonly DISPLAY_COLUMNS: (keyof AonHhvi5icPOS)[] = [
        'state',
        'hewittMarketName',
        'hewittName',
        'nationalNetwork',
        'planDiscountAll',
        'competitorAverage',
        'planClaimsAll',
        'marketClaimsAll',
        'claimsShareAll',
        'claimsVolumeFlagAll',
        'planDiscountIp',
        'planDiscountOp',
        'planDiscountPro',
        'planDiscountLab',
        'planDiscountRad',
        'inNetworkCompetitorAverageIp',
        'inNetworkCompetitorAverageOp',
        'inNetworkCompetitorAveragePro',
        'inNetworkCompetitorAverageLab',
        'inNetworkCompetitorAverageRad',
        'planClaimsIp',
        'planClaimsOp',
        'planClaimsPro',
        'planClaimsLab',
        'planClaimsRad',
        'marketClaimsIp',
        'marketClaimsOp',
        'marketClaimsPro',
        'marketClaimsLab',
        'marketClaimsRad',
        'claimsShareIp',
        'claimsShareOp',
        'claimsSharePro',
        'claimsShareLab',
        'claimsShareRad',
        'claimsVolumeFlagIp',
        'claimsVolumeFlagOp',
        'claimsVolumeFlagPro',
        'claimsVolumeFlagLab',
        'claimsVolumeFlagRad',
    ];
}
