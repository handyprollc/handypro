import { DB_BENCHMARKING } from '@app/common/constants';
import { NumberStringTransformer, StringNumberTransformer } from '@app/common/orm/transformer';
import { Column, Entity, PrimaryColumn } from 'typeorm';

/*Results - Non-Competing*/
@Entity('vw_dm_mercer_pmpm_noncompetiting_area', { database: DB_BENCHMARKING, schema: 'Benchmarking_App' })
export class MercerPMPMNonCompeting {
    @PrimaryColumn({ name: 'report_name' }) reportName: string;
    @PrimaryColumn({ name: 'selected_areas' }) selectedAreas: string;
    @PrimaryColumn({ name: 'Carrier' }) carrier: string;
    @PrimaryColumn({ name: 'netpic_2.0_relativity_score' }) netPic_2_0RelativityScore: number;
    @PrimaryColumn({ name: 'membership_bcbs_rank_by_pmpm' }) membershipBcbsRankByPmpm: number;
    @PrimaryColumn({ name: 'netpic_2.0_relativity_by_discount_ppo_only' }) netPic_2_0RelativityByDiscountPpoOnly: number;
    @PrimaryColumn({ name: 'risk_score' }) riskScore: number;
    @PrimaryColumn({ name: 'mercer_risk_score_carrier median' }) mercerRiskScoreCarrierMedian: number;
    @PrimaryColumn({ name: 'change_in_distance_from_lowest_cost_carrier' }) changeInDistanceFromLowestCostCarrier: string;
    @PrimaryColumn({ name: 'membership', transformer: new NumberStringTransformer() }) membership: number;
    @PrimaryColumn({ name: 'ppoonly_carrier' }) ppoOnlyCarrier: string;
    @PrimaryColumn({ name: 'ppoonly_netpic_2.0_relativity_score' }) ppoOnlyNetPic_2_0RelativityScore: number;
    @PrimaryColumn({ name: 'ppoonly_netpic_2.0_relativity_by_pmpm' }) ppoOnlyNetPic_2_0RelativityByPmpm: number;
    @PrimaryColumn({ name: 'ppoonly_netpic_2.0_relativity_by discount_ppo_only' }) ppoOnlyNetPic_2_0RelativityByDiscountPpoOnly: number;
    @PrimaryColumn({ name: 'upload_code' }) uploadCode: string;
    @PrimaryColumn({ name: 'carrier_id', transformer: new StringNumberTransformer() }) carrierId: string;
    @PrimaryColumn({ name: 'pdr_product_id' }) pdrProductId: string;
    @PrimaryColumn({ name: 'mercer_market_code' }) mercerMarketCode: string;
    @PrimaryColumn({ name: 'sequence_number' }) sequenceNumber: number;
    @PrimaryColumn({ name: 'type_of_calculation' }) typeOfCalculation: string;
    @PrimaryColumn({ name: 'batchseq' }) batchseq: number;
    @PrimaryColumn({ name: 'pdr_priority_flag' }) pdrPriorityFlag: number;
    @Column({ name: 'blended_carrier_id', type: 'simple-array' }) blindedCarrierId: string[];
    @PrimaryColumn({ name: 'blended_product_code' }) blindedProductCode: string;
    @PrimaryColumn({ name: 'sort_order' }) sortOrder: number;

    static readonly METADATA_COLUMNS: (keyof MercerPMPMNonCompeting)[] = [
        'carrierId', 'sortOrder', 'blindedCarrierId'
    ];

    static readonly DISPLAY_COLUMNS: (keyof MercerPMPMNonCompeting)[] = [
        'selectedAreas',
        'carrier',
        'netPic_2_0RelativityScore',
        'membershipBcbsRankByPmpm',
        'netPic_2_0RelativityByDiscountPpoOnly',
        'riskScore',
        'mercerRiskScoreCarrierMedian',
        'changeInDistanceFromLowestCostCarrier',
        'membership',
        'ppoOnlyCarrier',
        'ppoOnlyNetPic_2_0RelativityScore',
        'ppoOnlyNetPic_2_0RelativityByPmpm',
        'ppoOnlyNetPic_2_0RelativityByDiscountPpoOnly',
    ];
}