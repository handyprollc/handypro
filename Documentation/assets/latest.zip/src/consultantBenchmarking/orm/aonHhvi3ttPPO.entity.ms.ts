import { DB_BENCHMARKING } from '@app/common/constants';
import { Entity, PrimaryColumn } from 'typeorm';

/*
Total (PPO-HHVI-3Cat)
*/
@Entity('vw_dm_hhvi_3tt_ppo', { database: DB_BENCHMARKING, schema: 'Benchmarking_App' })
export class AonHhvi3ttPPO {
    @PrimaryColumn() carrierCode: string;
    @PrimaryColumn() readonly state: string;
    @PrimaryColumn() readonly hewittMarketName: string;
    @PrimaryColumn() readonly hewittName: string;
    @PrimaryColumn() readonly nationalNetwork: string;
    @PrimaryColumn() readonly chpProductTypeName: string;
    @PrimaryColumn() readonly planDiscountAll: number;
    @PrimaryColumn() readonly totalOonDiscount: number;
    @PrimaryColumn() readonly competitorAverage: number;
    @PrimaryColumn() readonly totalOonCompetitorAverage: number;
    @PrimaryColumn() readonly planClaimsAll: number;
    @PrimaryColumn() readonly marketClaimsAll: number;
    @PrimaryColumn() readonly claimsShareAll: number;
    @PrimaryColumn() readonly claimsVolumeFlagAll: string;
    @PrimaryColumn() readonly planDiscountIp: number;
    @PrimaryColumn() readonly planDiscountOp: number;
    @PrimaryColumn() readonly planDiscountPro: number;
    @PrimaryColumn() readonly inNetworkCompetitorAverageIp: number;
    @PrimaryColumn() readonly inNetworkCompetitorAverageOp: number;
    @PrimaryColumn() readonly inNetworkCompetitorAveragePro: number;
    @PrimaryColumn() readonly planClaimsIp: number;
    @PrimaryColumn() readonly planClaimsOp: number;
    @PrimaryColumn() readonly planClaimsPro: number;
    @PrimaryColumn() readonly marketClaimsIp: number;
    @PrimaryColumn() readonly marketClaimsOp: number;
    @PrimaryColumn() readonly marketClaimsPro: number;
    @PrimaryColumn() readonly claimsShareIp: number;
    @PrimaryColumn() readonly claimsShareOp: number;
    @PrimaryColumn() readonly claimsSharePro: number;
    @PrimaryColumn() readonly claimsVolumeFlagIp: string;
    @PrimaryColumn() readonly claimsVolumeFlagOp: string;
    @PrimaryColumn() readonly claimsVolumeFlagPro: string;
    @PrimaryColumn() readonly uploadCode: string;
    @PrimaryColumn() readonly reportType: string;

    static readonly METADATA_COLUMNS: (keyof AonHhvi3ttPPO)[] = [
        'carrierCode',
    ];

    static readonly DISPLAY_COLUMNS: (keyof AonHhvi3ttPPO)[] = [
        'state',
        'hewittMarketName',
        'hewittName',
        'nationalNetwork',
        'planDiscountAll',
        'totalOonDiscount',
        'competitorAverage',
        'totalOonCompetitorAverage',
        'planClaimsAll',
        'marketClaimsAll',
        'claimsShareAll',
        'claimsVolumeFlagAll',
        'planDiscountIp',
        'planDiscountOp',
        'planDiscountPro',
        'inNetworkCompetitorAverageIp',
        'inNetworkCompetitorAverageOp',
        'inNetworkCompetitorAveragePro',
        'planClaimsIp',
        'planClaimsOp',
        'planClaimsPro',
        'marketClaimsIp',
        'marketClaimsOp',
        'marketClaimsPro',
        'claimsShareIp',
        'claimsShareOp',
        'claimsSharePro',
        'claimsVolumeFlagIp',
        'claimsVolumeFlagOp',
        'claimsVolumeFlagPro',
    ];
}

