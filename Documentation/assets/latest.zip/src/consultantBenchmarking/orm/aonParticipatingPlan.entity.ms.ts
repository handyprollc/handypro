import { DB_BENCHMARKING } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Entity, PrimaryColumn } from 'typeorm';

@ObjectType()
@Entity('vw_hewitt_participating_plans', { database: DB_BENCHMARKING, schema: 'Benchmarking_App' })
export class AonParticipatingPlan {
    @Field({ nullable: true }) @PrimaryColumn() readonly uploadCode: number;
    @Field({ nullable: true }) @PrimaryColumn() readonly dimUploadKey: number;
    @Field({ nullable: true }) @PrimaryColumn() readonly blueVsCompetitorFlag: string;
    @Field({ nullable: true }) @PrimaryColumn() readonly carrierId: number;
    @Field({ nullable: true }) @PrimaryColumn() readonly carrierName: string;
    @Field({ nullable: true }) @PrimaryColumn() readonly networkName: string;
    @Field({ nullable: true }) @PrimaryColumn() readonly networkType: string;
    @Field({ nullable: true }) @PrimaryColumn() readonly productType: string;
    @Field({ nullable: true }) @PrimaryColumn() readonly reportSpecificNetworkType: string;
}


