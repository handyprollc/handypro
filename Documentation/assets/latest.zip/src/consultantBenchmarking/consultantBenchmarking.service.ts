import { MSSQL } from '@app/common/constants';
import { Injectable, Logger } from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import { EntityManager } from 'typeorm';
import { DataUpload, DataUploadCritera } from './orm/dataUpload.entity.ms';


@Injectable()
export class ConsultantBenchmarkingService {

  protected readonly logger = new Logger('ConsultantBenchmarkingService');

  constructor(
    @InjectEntityManager(MSSQL)
    private readonly em: EntityManager,
  ) { }

  queryDataUploads(criteria: Partial<DataUploadCritera>): Promise<DataUpload[]> {
    return this.em.getRepository(DataUpload).find({
      where: { ...criteria }
    });
  }

}
