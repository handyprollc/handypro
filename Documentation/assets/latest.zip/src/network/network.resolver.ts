import { Validator } from '@app/common/pipe/validator.pipe';
import { TabularData } from '@app/common/scalars/tabularData';
import { Controller, Get, Param, ParseIntPipe } from '@nestjs/common';
import { Args, Query, Resolver } from '@nestjs/graphql';
import _ from 'lodash';
import { Network } from './network.entity.ms';
import { NetworkService } from './network.service';

@Resolver('Network')
@Controller('carrierNetwork')
export class NetworkResolver {
  constructor(private readonly networkService: NetworkService) { }

  @Query(returns => [Network], { name: 'network_findByDataset' })
  findNetworks(@Args('datasetId') datasetId: number): Promise<Network[]> {
    return this.networkService.findNetworks(datasetId);
  }

  @Get('getByDataset/:datasetId')
  async getByDataset(
    @Param(
      'datasetId',
      new ParseIntPipe(),
      new Validator({ type: 'integer', minLength: 1 })
    ) datasetId: number): Promise<TabularData> {
    const networks = await this.networkService.findNetworks(datasetId);
    const results = await Promise.all(networks.map(async nwk => {
      const carrier = await Promise.resolve(nwk.carrier);
      const benchmarkingName = await Promise.resolve(carrier.benchmarkingName);
      const carrierName = _.isEmpty(benchmarkingName) ? carrier.marketName : benchmarkingName.name;
      return {
        carrierName,
        productName: nwk.name,
        productType: nwk.productType,
      };
    }));
    return new TabularData(
      _.sortBy(
        results,
        ['carrierName', 'productType']
      ));
  }

}
