import { Carrier } from '@app/carrier2/carrier.entity.ms';
import { DB_BENCHMARKING } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';

@ObjectType()
@Entity('networks', { database: DB_BENCHMARKING, schema: 'carriers' })
export class Network {
    @Field()
    @PrimaryGeneratedColumn({ name: 'data_set' })
    readonly dataset: number;
    @Field({ nullable: true })
    @PrimaryGeneratedColumn()
    name: string;
    @Field({ nullable: true })
    @PrimaryGeneratedColumn()
    type: string;
    @Field({ nullable: true })
    @PrimaryGeneratedColumn()
    productType: string;
    @Field({ nullable: true })
    @PrimaryGeneratedColumn({ name: 'carrier' })
    carrierId: number;
    @Field(type => Carrier, { nullable: true })
    @ManyToOne(type => Carrier, { lazy: true })
    @JoinColumn({ name: 'carrier' })
    carrier: Carrier;
}