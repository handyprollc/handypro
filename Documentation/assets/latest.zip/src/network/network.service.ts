import { MSSQL } from '@app/common/constants';
import { Network } from '@app/network/network.entity.ms';
import { Injectable, Logger } from '@nestjs/common';
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm';
import { EntityManager, Repository } from 'typeorm';

@Injectable()
export class NetworkService {
  protected readonly logger = new Logger('NetworkService');

  constructor(
    @InjectEntityManager(MSSQL)
    private readonly em: EntityManager,
    @InjectRepository(Network, MSSQL)
    private readonly networkRepo: Repository<Network>,
  ) { }

  async findNetworks(dataset: number): Promise<Network[]> {
    return await this.networkRepo.find({
      join: {
        alias: 'nwt',
        innerJoinAndSelect: {
          carrier: 'nwt.carrier',
          name: 'carrier.benchmarkingName',
        }
      },
      where: { dataset },
      order: {
        carrierId: 'ASC',
        // name: 'ASC',
      },
    });
  }
}