import { MSSQL } from '@app/common/constants';
import { Network } from '@app/network/network.entity.ms';
import { NetworkService } from '@app/network/network.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NetworkResolver } from './network.resolver';


@Module({
  imports: [TypeOrmModule.forFeature([Network], MSSQL)],
  providers: [NetworkService, NetworkResolver],
  exports: [NetworkService],
  controllers: [NetworkResolver]
})
export class NetworkModule { }