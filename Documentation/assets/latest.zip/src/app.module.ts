import { CarrierModule } from '@app/carrier/carrier.module';
import { MSSQL, PG_DATAMART, PG_DM, PG_FDM } from '@app/common/constants';
import { NetworkModule } from '@app/network/network.module';
import { ReferenceModule } from '@app/reference/reference.module';
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { TypeOrmModule } from '@nestjs/typeorm';
import { resolve } from 'path';
import { CompanyModule } from './company/company.module';
import configs from './config';
import { ConsultantBenchmarkingModule } from './consultantBenchmarking/consultantBenchmarking.module';
import { DocumentModule } from './document/document.module';
import { EmployerModule } from './employer/employer.module';
import { GeographyModule } from './geography/geography.module';
import { IdentityModule } from './identity/identity.module';
import { SecurityModule } from './security/security.module';
import { SystemModule } from './system/system.module';


@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: resolve(process.env.NODE_ENV_PATH, 'insights-service.env'),
      load: configs,
      isGlobal: true,
      expandVariables: true,
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      name: MSSQL,
      useFactory: (config: ConfigService) => config.get(MSSQL)(),
    }),
    TypeOrmModule.forRootAsync({
      name: PG_DM,
      useFactory: (config: ConfigService) => config.get(PG_DM)(),
      inject: [ConfigService],
    }),
    TypeOrmModule.forRootAsync({
      name: PG_DATAMART,
      useFactory: (config: ConfigService) => config.get(PG_DATAMART)(),
      inject: [ConfigService],
    }),
    TypeOrmModule.forRootAsync({
      name: PG_FDM,
      useFactory: (config: ConfigService) => config.get(PG_FDM)(),
      inject: [ConfigService],
    }),
    GraphQLModule.forRoot({
      installSubscriptionHandlers: true,
      useGlobalPrefix: true,
      autoSchemaFile: 'schema.gql',
      context: ({ req }) => ({ req })
    }),
    CompanyModule,
    ConsultantBenchmarkingModule,
    CarrierModule,
    DocumentModule,
    EmployerModule,
    GeographyModule,
    IdentityModule,
    NetworkModule,
    ReferenceModule,
    SecurityModule,
    SystemModule,
  ],
})
export class AppModule { }
