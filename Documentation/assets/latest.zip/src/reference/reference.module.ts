import { MSSQL, PG_FDM } from '@app/common/constants';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EmployeeCountBand } from './employer/employeeCountBand.entity.pg.fdm';
import { FortuneRankBand } from './employer/fortuneRankBand.entity.pg.fdm';
import { NaicsNationalIndustry } from './naics/nationaIIndustry.entity.ms';
import { ReferenceResolver } from './reference.resolver';
import { ReferenceService } from './reference.service';
import { Industry } from './sic/industry.entity.ms';

@Module({
  imports: [
    TypeOrmModule.forFeature([Industry, NaicsNationalIndustry], MSSQL),
    TypeOrmModule.forFeature([EmployeeCountBand, FortuneRankBand], PG_FDM),
  ],
  providers: [ReferenceResolver, ReferenceService],
  exports: [ReferenceService],
})
export class ReferenceModule { }
