import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@ObjectType('Employer_FortuneRankBand')
@Entity('fortune_rank', { schema: 'employer' })
export class FortuneRankBand {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field()
    @Column()
    code: string;
}