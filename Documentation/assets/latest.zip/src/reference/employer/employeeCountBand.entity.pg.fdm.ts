import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@ObjectType('Employer_EmployeeCountBand')
@Entity('employee_count', { schema: 'employer' })
export class EmployeeCountBand {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field()
    @Column()
    code: string;
}