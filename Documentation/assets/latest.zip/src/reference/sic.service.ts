import { MSSQL } from '@app/common/constants';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Naics } from './naics/naics';
import { NaicsNationalIndustry } from './naics/nationaIIndustry.entity.ms';
import { Industry } from './sic/industry.entity.ms';
import { SIC } from './sic/sic';

@Injectable()
export class SicService {
  constructor(
    @InjectRepository(Industry, MSSQL)
    private readonly sicRepo: Repository<Industry>,
  ) { }

  public async listSIC(): Promise<SIC[]> {
    const qb = this.sicRepo
      .createQueryBuilder('i')
      .innerJoin('i.group', 'g')
      .innerJoin('g.majorGroup', 'm')
      .innerJoin('m.division', 'd')
      .select('d.code', 'divisionCode')
      .addSelect('d.name', 'divisionName')
      .addSelect('m.id', 'majorGroupCode')
      .addSelect('m.name', 'majorGroupName')
      .addSelect('i.id', 'industryCode')
      .addSelect('i.name', 'industryName');
    return qb.getRawMany();
  }

}