import { MSSQL, PG_FDM } from '@app/common/constants';
import { Injectable } from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import { EntityManager } from 'typeorm';
import { EmployeeCountBand } from './employer/employeeCountBand.entity.pg.fdm';
import { FortuneRankBand } from './employer/fortuneRankBand.entity.pg.fdm';
import { Naics } from './naics/naics';
import { NaicsNationalIndustry } from './naics/nationaIIndustry.entity.ms';
import { Industry } from './sic/industry.entity.ms';
import { SIC } from './sic/sic';

@Injectable()
export class ReferenceService {
  constructor(
    @InjectEntityManager(MSSQL)
    private readonly msEntityMgr: EntityManager,
    @InjectEntityManager(PG_FDM)
    private readonly pgEntityMgr: EntityManager,
  ) { }

  public listSIC(): Promise<SIC[]> {
    const qb = this.msEntityMgr.getRepository(Industry)
      .createQueryBuilder('i')
      .innerJoin('i.group', 'g')
      .innerJoin('g.majorGroup', 'm')
      .innerJoin('m.division', 'd')
      .select('d.code', 'divisionCode')
      .addSelect('d.name', 'divisionName')
      .addSelect('m.id', 'majorGroupCode')
      .addSelect('m.name', 'majorGroupName')
      .addSelect('i.id', 'industryCode')
      .addSelect('i.name', 'industryName');
    return qb.getRawMany();
  }

  public listNaics(): Promise<Naics[]> {
    const qb = this.msEntityMgr.getRepository(NaicsNationalIndustry)
      .createQueryBuilder('n')
      .innerJoin('n.industry', 'i')
      .innerJoin('i.group', 'g')
      .innerJoin('g.subSector', 'u')
      .innerJoin('u.sector', 's')
      .select('n.id', 'code')
      .addSelect('n.name', 'name')
      .addSelect('s.id', 'sectorCode')
      .addSelect('s.name', 'sectorName');
    return qb.getRawMany();
  }

  public listEmployeeCountBand(): Promise<EmployeeCountBand[]> {
    return this.pgEntityMgr.getRepository(EmployeeCountBand).find();
  }

  public listFortuneRankBand(): Promise<FortuneRankBand[]> {
    return this.pgEntityMgr.getRepository(FortuneRankBand).find();
  }

}