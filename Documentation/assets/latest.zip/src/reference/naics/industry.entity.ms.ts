import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { NaicsGroup } from './group.entity.ms';

@ObjectType('NAICS_Industry')
@Entity('naics_industries', { database: DB_IDS, schema: 'app_transfer' })
export class NaicsIndustry {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field()
    @Column({ name: 'group' })
    grouId: number;
    @Field(type => NaicsGroup, { nullable: true })
    @ManyToOne(type => NaicsGroup, group => group.id, { lazy: true })
    @JoinColumn({ name: 'group' })
    group: NaicsGroup;
}
