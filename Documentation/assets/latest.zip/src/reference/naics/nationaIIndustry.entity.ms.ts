import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { NaicsIndustry } from './industry.entity.ms';

@ObjectType('NAICS_NationalIndustry')
@Entity('naics_national_industries', { database: DB_IDS, schema: 'app_transfer' })
export class NaicsNationalIndustry {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field()
    @Column({ name: 'industry' })
    industryId: number;
    @Field(type => NaicsIndustry, { nullable: true })
    @ManyToOne(type => NaicsIndustry, industry => industry.id, { lazy: true })
    @JoinColumn({ name: 'industry' })
    industry: NaicsIndustry;
}
