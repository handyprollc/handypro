import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { NaicsSubSector } from './subSector.entity.ms';

@ObjectType('NAICS_Group')
@Entity('naics_groups', { database: DB_IDS, schema: 'app_transfer' })
export class NaicsGroup {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field()
    @Column({ name: 'subsector' })
    subSectorId: number;
    @Field(type => NaicsSubSector, { nullable: true })
    @ManyToOne(type => NaicsSubSector, subsector => subsector.id, { lazy: true })
    @JoinColumn({ name: 'subsector' })
    subSector: NaicsSubSector;

}
