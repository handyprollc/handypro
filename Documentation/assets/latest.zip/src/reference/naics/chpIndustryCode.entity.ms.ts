import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@ObjectType('NAICS_ChpIndustryCode')
@Entity('naics_chp_industry_codes', { database: DB_IDS, schema: 'app_transfer' })
export class ChpIndustryCode {
    @Field()
    @PrimaryColumn()
    readonly code: string;
    @Field()
    @Column()
    name: string;
}
