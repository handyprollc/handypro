import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { NaicsSector } from './sector.entity.ms';

@ObjectType('NAICS_SubSector')
@Entity('naics_subsectors', { database: DB_IDS, schema: 'app_transfer' })
export class NaicsSubSector {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field()
    @Column({ name: 'sector' })
    sectorId: number;
    @Field(type => NaicsSector, { nullable: true })
    @ManyToOne(type => NaicsSector, sector => sector.id, { lazy: true })
    @JoinColumn({ name: 'sector' })
    sector: NaicsSector;
}
