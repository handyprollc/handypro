import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType('SIC_Naics')
export class Naics {
   @Field({ nullable: true })
   sectorCode: number;
   @Field({ nullable: true })
   sectorName: string;
   @Field({ nullable: true })
   code: number;
   @Field({ nullable: true })
   name: string;
}
/*

naics_sector_code
naics_sector_name
naics_national_code
naics_national_name

-- View: refer.naics

-- DROP VIEW refer.naics;

CREATE OR REPLACE VIEW refer.naics AS
 SELECT n.id::text AS naics,
    'NAICS'::text AS naics_all_name,
    '1'::text AS naics_all_code,
    c.name AS chp_industry_name,
    c.code AS chp_industry_code,
    s.name AS naics_sector_name,
    s.id::text AS naics_sector_code,
    u.name AS naics_subsector_name,
    u.id::text AS naics_subsector_code,
    g.name AS naics_group_name,
    g.id::text AS naics_group_code,
    i.name AS naics_industry_name,
    i.id::text AS naics_industry_code,
    n.name AS naics_national_name,
    n.id::text AS naics_national_code
   FROM naics.national_industries n
     JOIN naics.industries i ON i.id = n.industry
     JOIN naics.groups g ON g.id = i."group"
     JOIN naics.subsectors u ON u.id = g.subsector
     JOIN naics.sectors s ON s.id = u.sector
     JOIN naics.chp_sectors x ON x.sector = s.id
     JOIN naics.chp_industry_codes c ON c.code = x.chp_code
UNION ALL
 SELECT i.id::text AS naics,
    'NAICS'::text AS naics_all_name,
    '1'::text AS naics_all_code,
    c.name AS chp_industry_name,
    c.code AS chp_industry_code,
    s.name AS naics_sector_name,
    s.id::text AS naics_sector_code,
    u.name AS naics_subsector_name,
    u.id::text AS naics_subsector_code,
    g.name AS naics_group_name,
    g.id::text AS naics_group_code,
    i.name AS naics_industry_name,
    i.id::text AS naics_industry_code,
    NULL::text AS naics_national_name,
    NULL::text AS naics_national_code
   FROM naics.industries i
     JOIN naics.groups g ON g.id = i."group"
     JOIN naics.subsectors u ON u.id = g.subsector
     JOIN naics.sectors s ON s.id = u.sector
     JOIN naics.chp_sectors x ON x.sector = s.id
     JOIN naics.chp_industry_codes c ON c.code = x.chp_code
UNION ALL
 SELECT g.id::text AS naics,
    'NAICS'::text AS naics_all_name,
    '1'::text AS naics_all_code,
    c.name AS chp_industry_name,
    c.code AS chp_industry_code,
    s.name AS naics_sector_name,
    s.id::text AS naics_sector_code,
    u.name AS naics_subsector_name,
    u.id::text AS naics_subsector_code,
    g.name AS naics_group_name,
    g.id::text AS naics_group_code,
    NULL::text AS naics_industry_name,
    NULL::text AS naics_industry_code,
    NULL::text AS naics_national_name,
    NULL::text AS naics_national_code
   FROM naics.groups g
     JOIN naics.subsectors u ON u.id = g.subsector
     JOIN naics.sectors s ON s.id = u.sector
     JOIN naics.chp_sectors x ON x.sector = s.id
     JOIN naics.chp_industry_codes c ON c.code = x.chp_code
UNION ALL
 SELECT u.id::text AS naics,
    'NAICS'::text AS naics_all_name,
    '1'::text AS naics_all_code,
    c.name AS chp_industry_name,
    c.code AS chp_industry_code,
    s.name AS naics_sector_name,
    s.id::text AS naics_sector_code,
    u.name AS naics_subsector_name,
    u.id::text AS naics_subsector_code,
    NULL::text AS naics_group_name,
    NULL::text AS naics_group_code,
    NULL::text AS naics_industry_name,
    NULL::text AS naics_industry_code,
    NULL::text AS naics_national_name,
    NULL::text AS naics_national_code
   FROM naics.subsectors u
     JOIN naics.sectors s ON s.id = u.sector
     JOIN naics.chp_sectors x ON x.sector = s.id
     JOIN naics.chp_industry_codes c ON c.code = x.chp_code
UNION ALL
 SELECT s.id::text AS naics,
    'NAICS'::text AS naics_all_name,
    '1'::text AS naics_all_code,
    c.name AS chp_industry_name,
    c.code AS chp_industry_code,
    s.name AS naics_sector_name,
    s.id::text AS naics_sector_code,
    NULL::text AS naics_subsector_name,
    NULL::text AS naics_subsector_code,
    NULL::text AS naics_group_name,
    NULL::text AS naics_group_code,
    NULL::text AS naics_industry_name,
    NULL::text AS naics_industry_code,
    NULL::text AS naics_national_name,
    NULL::text AS naics_national_code
   FROM naics.sectors s
     JOIN naics.chp_sectors x ON x.sector = s.id
     JOIN naics.chp_industry_codes c ON c.code = x.chp_code
UNION ALL
 SELECT chp_industry_codes.code AS naics,
    'NAICS'::text AS naics_all_name,
    '1'::text AS naics_all_code,
    chp_industry_codes.name AS chp_industry_name,
    chp_industry_codes.code AS chp_industry_code,
    NULL::text AS naics_sector_name,
    NULL::text AS naics_sector_code,
    NULL::text AS naics_subsector_name,
    NULL::text AS naics_subsector_code,
    NULL::text AS naics_group_name,
    NULL::text AS naics_group_code,
    NULL::text AS naics_industry_name,
    NULL::text AS naics_industry_code,
    NULL::text AS naics_national_name,
    NULL::text AS naics_national_code
   FROM naics.chp_industry_codes
UNION ALL
 SELECT v.naics,
    v.naics_all_name,
    v.naics_all_code,
    v.chp_industry_name,
    v.chp_industry_code,
    v.naics_sector_name,
    v.naics_sector_code,
    v.naics_subsector_name,
    v.naics_subsector_code,
    v.naics_group_name,
    v.naics_group_code,
    v.naics_industry_name,
    v.naics_industry_code,
    v.naics_national_name,
    v.naics_national_code
   FROM ( VALUES ('1'::text,'NAICS'::text,'1'::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text,NULL::text)) v(naics, naics_all_name, naics_all_code, chp_industry_name, chp_industry_code, naics_sector_name, naics_sector_code, naics_subsector_name, naics_subsector_code, naics_group_name, naics_group_code, naics_industry_name, naics_industry_code, naics_national_name, naics_national_code);

ALTER TABLE refer.naics
  OWNER TO postgres;
GRANT ALL ON TABLE refer.naics TO postgres;
GRANT SELECT ON TABLE refer.naics TO staff;
GRANT SELECT ON TABLE refer.naics TO foundation_data_management;

 */