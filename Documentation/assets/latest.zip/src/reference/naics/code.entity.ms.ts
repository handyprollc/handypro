import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@ObjectType('NAICS_Code')
@Entity('naics_codes', { database: DB_IDS, schema: 'app_transfer' })
export class ChpIndustryCode {
    @Field()
    @PrimaryColumn()
    readonly id: number;
}