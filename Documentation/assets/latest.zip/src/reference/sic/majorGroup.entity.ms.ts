import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { Division } from './division.entity.ms';

@ObjectType('SIC_IndustryMajorGroup')
@Entity('sic_major_groups', { database: DB_IDS, schema: 'app_transfer' })
export class MajorGroup {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field(type => Division, { nullable: true })
    @ManyToOne(type => Division, { lazy: true })
    @JoinColumn({ name: 'division' })
    division: Division;
}
