import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { MajorGroup } from './majorGroup.entity.ms';

@ObjectType('SIC_IndustryGroup')
@Entity('sic_industry_groups', { database: DB_IDS, schema: 'app_transfer' })
export class IndustryGroup {
    @Field()
    @PrimaryColumn()
    readonly id: number;
    @Field()
    @Column()
    name: string;
    @Field(type => MajorGroup, { nullable: true })
    @ManyToOne(type => MajorGroup, { lazy: true })
    @JoinColumn({ name: 'major_group' })
    majorGroup: MajorGroup;
}
