import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@ObjectType('SIC_Division')
@Entity('sic_divisions', { database: DB_IDS, schema: 'app_transfer' })
export class Division {
    @Field()
    @PrimaryColumn()
    readonly code: string;
    @Field()
    @Column()
    name: string;
}
