import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType('SIC_sic')
export class SIC {
    @Field()
    divisionCode: string;
    @Field()
    divisionName: string;
    @Field()
    majorGroupCode: string;
    @Field()
    majorGroupName: string;
    @Field()
    industryCode: string;
    @Field()
    industryName: string;
}
