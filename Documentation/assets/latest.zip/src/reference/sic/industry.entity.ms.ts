import { DB_IDS } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { AfterLoad, Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { IndustryGroup } from './industryGroup.entity.ms';

@ObjectType('SIC_Industry')
@Entity('sic_industries', { database: DB_IDS, schema: 'app_transfer' })
export class Industry {
    @Field()
    @PrimaryColumn()
    id: string;
    @Field()
    @Column()
    name: string;
    @Field(type => IndustryGroup, { nullable: true })
    @ManyToOne(type => IndustryGroup, { lazy: true })
    @JoinColumn({ name: 'industry_group' })
    group: IndustryGroup;
    @AfterLoad()
    lpadID() {
        this.id = this.id.padStart(4, '0');
    }

}
