import { AuthGuard } from '@app/security/auth.guard';
import { UseGuards } from '@nestjs/common';
import { Query, Resolver } from '@nestjs/graphql';
import { EmployeeCountBand } from './employer/employeeCountBand.entity.pg.fdm';
import { FortuneRankBand } from './employer/fortuneRankBand.entity.pg.fdm';
import { Naics } from './naics/naics';
import { ReferenceService } from './reference.service';
import { SIC } from './sic/sic';

@Resolver('Reference')
export class ReferenceResolver {
  constructor(private readonly referenceService: ReferenceService) { }

  @Query(returns => [SIC], { name: 'reference_sic' })
  @UseGuards(AuthGuard)
  listSIC(): Promise<SIC[]> {
    return this.referenceService.listSIC();
  }
  @Query(returns => [Naics], { name: 'reference_naics' })
  @UseGuards(AuthGuard)
  listNaics(): Promise<Naics[]> {
    return this.referenceService.listNaics();
  }

  @Query(returns => [EmployeeCountBand], { name: 'reference_employeeCountBand' })
  @UseGuards(AuthGuard)
  public listEmployeeCountBand(): Promise<EmployeeCountBand[]> {
    return this.referenceService.listEmployeeCountBand();
  }

  @Query(returns => [FortuneRankBand], { name: 'reference_fortuneRankBand' })
  @UseGuards(AuthGuard)
  public listFortuneRankBand(): Promise<FortuneRankBand[]> {
    return this.referenceService.listFortuneRankBand();
  }


}
