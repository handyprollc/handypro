import { MSSQL } from '@app/common/constants';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Naics } from './naics/naics';
import { NaicsNationalIndustry } from './naics/nationaIIndustry.entity.ms';

@Injectable()
export class NaicsService {
  constructor(
    @InjectRepository(NaicsNationalIndustry, MSSQL)
    private readonly naicsRepo: Repository<NaicsNationalIndustry>,
  ) { }


  public async listNaics(): Promise<Naics[]> {
    const qb = this.naicsRepo
      .createQueryBuilder('n')
      .innerJoin('n.industry', 'i')
      .innerJoin('i.group', 'g')
      .innerJoin('g.subSector', 'u')
      .innerJoin('u.sector', 's')
      .select('n.id', 'code')
      .addSelect('n.name', 'name')
      .addSelect('s.id', 'sectorCode')
      .addSelect('s.name', 'sectorName');
    return qb.getRawMany();
  }
}