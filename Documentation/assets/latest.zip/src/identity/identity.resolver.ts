import { Controller, Get, Req } from '@nestjs/common';
import { Context, Query, Resolver } from '@nestjs/graphql';
import { Request } from 'express';
import { Identity } from './identity.model';
import { IdentityService } from './identity.service';

@Controller('identity')
@Resolver('Identity')
export class IdentityResolver {
  constructor(private readonly identityService: IdentityService) { }

  @Query(returns => Identity, { name: 'identity_profile' })
  getProfile(@Context() { req }): Identity | Promise<Identity> {
    return this.identityService.getProfile(req)
  }

  @Get('identify')
  identify(@Req() req: Request): Identity | Promise<Identity> {
    return this.identityService.identify(req);
  }
}


