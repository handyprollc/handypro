import { Carrier } from '@app/carrier/carrier.entity.pg.fdm';
import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class Identity {
    public constructor(init?: Partial<Identity>) {
        Object.assign(this, init);
    }
    @Field()
    emailAddress: string;
    @Field()
    organization: string;
    @Field()
    screenName: string;
    @Field()
    carrierID: string;
    @Field()
    userType: string;
    @Field({ nullable: true })
    carrier?: Carrier;
}
