import { Carrier } from '@app/carrier/carrier.entity.pg.fdm';
import { CarrierService } from '@app/carrier/carrier.service';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthenticationError } from 'apollo-server-core';
import { Request } from 'express';
import * as fs from 'fs';
import * as jwt from 'jsonwebtoken';
import { resolve } from 'path';
import { Identity } from './identity.model';

@Injectable()
export class IdentityService {
    constructor(private readonly carrierService: CarrierService) { }

    public identify(request: Request): Identity {
        const token: string = this.exactTokenFromRequest(request);
        return this.decodeJWT(token);
    }

    public async getProfile(request: Request): Promise<Identity> {
        const decoded: Identity = this.identify(request);
        const carrier: Carrier = await this.carrierService.getCarrier(decoded.carrierID);
        return new Identity({ ...decoded, carrier });
    }

    public encodeJWT(payload: object): string {
        const pem: string = this.findCertificates()[0];
        return jwt.sign(payload, pem, { expiresIn: '1d' });
    }


    public decodeJWT(token: string): Identity {
        const pems: string[] = this.findCertificates();
        let identity: Identity = null;
        let error = null;
        for (const pem of pems) {
            try {
                identity = jwt.verify(token, pem, { algorithms: ['HS256'] }) as Identity;
                if (!!identity)
                    break;
            } catch (e) {
                error = e;
            }
        }
        if (!identity) {
            throw new UnauthorizedException();
        }
        return identity;
    }

    private findCertificates(): string[] {
        const certDir = fs.readdirSync(process.env.NODE_ENV_PATH);
        const certs = certDir
            .filter(f => f.match(/.*\.consortiuminsights-liferay.pem/ig))
            .map(f => {
                const cert = fs.readFileSync(resolve(process.env.NODE_ENV_PATH, f));
                const pem = /-----BEGIN (\w*)-----([^-]*)-----END (\w*)-----/g.exec(cert.toString());
                return pem[2].replace(/[\n|\r\n]/g, '');
            });
        return certs;
    }

    private exactTokenFromRequest(req: Request): string {
        const token = req.get('Authorization') || '';
        const matches = token.match(/bearer\s+(.+)$/i);
        if (matches && matches.length === 2) {
            return matches[1];
        } else {
            throw new AuthenticationError('Request must contain Bearer Authorization in header');
        }
    }
}

