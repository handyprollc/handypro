import { CarrierModule } from '@app/carrier/carrier.module';
import { Global, Module } from '@nestjs/common';
import { IdentityResolver } from './identity.resolver';
import { IdentityService } from './identity.service';

@Global()
@Module({
  imports: [CarrierModule],
  providers: [IdentityResolver, IdentityService],
  exports: [IdentityService],
  controllers: [IdentityResolver]
})
export class IdentityModule { }
