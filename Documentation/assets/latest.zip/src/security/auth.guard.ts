import { Identity } from '@app/identity/identity.model';
import { IdentityService } from '@app/identity/identity.service';
import { CanActivate, ContextType, ExecutionContext, Inject, Injectable } from '@nestjs/common';
import { GqlExecutionContext } from '@nestjs/graphql';
import { Request } from 'express';
import _ from 'lodash';

@Injectable()
export class AuthGuard implements CanActivate {
  private static readonly SUPER_CARRIER_IDS = ['889'];

  constructor(
    @Inject(IdentityService) private readonly identityService: IdentityService,
  ) { }

  async canActivate(context: ExecutionContext): Promise<boolean> {
    let request: Request;
    let args: object[];
    const contextType: ContextType = context.getType();
    switch (contextType) {
      case 'http':
        request = context.switchToHttp().getRequest();
        args = [request.params, request.query];
        break;
      case 'rpc':
        request = context.switchToRpc().getContext().getRequest();
        args = [request.params, request.query];
        break;
      case 'ws':
        request = context.switchToWs().getClient().getRequest();
        args = [request.params, request.query];
        break;
      default:
        const gqlCtx = GqlExecutionContext.create(context);
        request = (await gqlCtx.getContext()).req;
        args = [gqlCtx.getArgs()];
        break;
    }
    const identity: Identity = this.identityService.identify(request);
    return this.canAccess(identity, args);
  }

  private canAccess(identity: Identity, args: object[]): boolean {
    if (!identity) return false;
    const { carrierID } = identity;
    if (!AuthGuard.SUPER_CARRIER_IDS.includes(carrierID)) {
      // Check requested CarrierID vs identity carrierID
      return !args
        .flatMap(arg => Object.values(_.pick(arg, ['carrierId', 'carrierID', 'carrierCode'])))
        .some(id => !!id && _.toString(id) !== carrierID);
    }
    return true;
  }

}