import { DB_BENCHMARKING } from '@app/common/constants';
import { Column, Entity, PrimaryColumn } from 'typeorm';

/*
IC (PPO-HHVI-3Cat)
*/
@Entity('carrier_restriction', { database: DB_BENCHMARKING })
export class CarrierRestriction {
    @PrimaryColumn() readonly id: string;
    @Column() carrierGroupCode: string;
    @Column() carrierCode: string;
    @Column() restrictedCarrierCode: string;
    @Column() application: string;
    @Column() restrictedRule: string;
}