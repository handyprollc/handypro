import { MSSQL } from '@app/common/constants';
import { Identity } from '@app/identity/identity.model';
import { IdentityService } from '@app/identity/identity.service';
import { Injectable, Logger } from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import { Request } from 'express';
import { EntityManager } from 'typeorm';
import { CarrierRestriction } from './orm/carrierRestriction.entity.ms';

@Injectable()
export class SecurityService {
  protected readonly logger = new Logger('SecurityService');

  constructor(
    private readonly identityService: IdentityService,

    @InjectEntityManager(MSSQL)
    private readonly em: EntityManager,
  ) { }


  getRestrictRules(identity: Identity): Promise<CarrierRestriction[]> {
    return this.em.getRepository(CarrierRestriction).find({
      where: {
        carrierCode: identity.carrierID
      },
    });
  }

  getRestrictRulesFromRequest(request: Request): Promise<CarrierRestriction[]> {
    return this.getRestrictRules(this.identityService.identify(request));
  }
}
