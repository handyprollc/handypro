import { IdentityModule } from '@app/identity/identity.module';
import { Module } from '@nestjs/common';
import { SecurityService } from './security.service';


@Module({
  imports: [IdentityModule,],
  providers: [SecurityService],
  exports: [SecurityService],
})
export class SecurityModule { }
