import { ExcelJSUtils } from '@app/document/exceljs.utils';
import { Logger } from '@nestjs/common';
import Excel, { Cell } from 'exceljs';
import _ from 'lodash';
import { join } from 'path';

export class ExcelService {
    private readonly logger = new Logger('ExcelService');


    private fillCell(cell: Cell, value: any) {
        if (!cell || !value) return;
        if (value.hasOwnProperty('value') || value.hasOwnProperty('text'))
            Object.keys(value).forEach(k => cell[k] = value[k]);
        else
            cell.value = value;
    }

    private getLiteralValue(context: any, v: any) {
        if (_.isString(v)) {
            const match = (/\${([^}]+)}/g).exec(v);
            if (!_.isEmpty(match)) {
                const key = match[1];
                return context[key] || '';
            }
        }
        return v;
    }

    public async generate({ path, output, data }) {
        const xslt = new Excel.Workbook().xlsx;
        const template = await xslt.readFile(path);
        if (!_.isEmpty(data)) {
            for (const { sheet, rows, cells, literals } of data) {
                const ws = template.getWorksheet(sheet);
                if (!ws) {
                    this.logger.warn(`Sheet[${sheet}] is not found in : ${path}`);
                    continue;
                }
                if (!_.isEmpty(cells)) {
                    for (const [ref, it] of cells) {
                        const cell = ws.getCell(ref);
                        this.fillCell(cell, it);
                    }
                }
                if (!_.isEmpty(rows)) {
                    for (const [ref, rowVals] of rows) {
                        const l = rowVals.length;
                        const w = rowVals[0].length;
                        const placeholder = Array.from(Array(l), () => Array(w).fill(''));
                        ws.spliceRows(ref, 0, ...placeholder);
                        for (let row = ref; row < ref + l; row++) {
                            let col = 0;
                            ws.getRow(row).eachCell(cell => {
                                const it = rowVals[row - ref][col++];
                                this.fillCell(cell, it);
                            });
                        }
                    }
                }
                if (!_.isEmpty(literals)) {
                    for (const { template: [r1, r2], data: vals } of literals) {
                        const rowsSrc = _.range(r1, r2).map(r => ws.getRow(r));
                        ws.spliceRows(r2 + 1, 0, ...new Array((r2 - r1) * vals.length).fill(''));
                        vals.forEach((val, i) => {
                            rowsSrc.forEach((rSrc, rOffset) => {
                                const rDstNum = r2 + i * rowsSrc.length + rOffset;
                                const rDst = ws.getRow(rDstNum);
                                if (_.isArray(rSrc.values)) {
                                    const inserts = rSrc.values.map(v => this.getLiteralValue(val, v));
                                    rDst.values = inserts;
                                    rDst.height = rSrc.height;
                                    rSrc.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                                        rDst.getCell(colNumber).style = cell.style;
                                    });
                                }
                            });
                        });
                        ws.spliceRows(r1, r2 - r1);
                    }
                }
            }
        }
        xslt.writeFile(output);
    }

}
const ROOD_DIR = join(__dirname, '..', '..');
const entries = [
    [{ value: 'American Family Care Inc.', style: { font: { bold: true } } }, '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
    ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
    ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
    ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
    ['American Family Care Inc.', {
        value: 32, fill: {
            type: 'pattern',
            pattern: 'darkTrellis',
            fgColor: { argb: 'FFFFFF00' },
            bgColor: { argb: 'FF0000FF' }
        }
    }, '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
];

const excel = new ExcelService();
excel.generate({
    path: join(ROOD_DIR, 'templates', 'employer-search', 'CompanyProfileReport.xlsx'),
    output: join(ROOD_DIR, 'logs', `CompanyProfileReport_${(Date.now() % 1000)}.xlsx`),
    data: [
        {
            'sheet': 'Sheet1',
            // rows: [
            //     [6, entries],
            // ],
            'cells': [
                // ['C12', { value: '4/15/2015', style: { font: { bold: true, name: 'Comic Sans MS' } } }],
                // ['C14', { value: '4/1/2020' }],
                // ['C16', { value: '4/1/2020' }],
                // ['C18', 'DE - Highmark BCBS,PA - Highmark BCBS,PA - Highmark BS,WV - Highmark BCBS'],
                // ['H14', { value: '4/1/2020' }],
                // ['H16', { value: '40 - Railroad Transportation, 41 - Local and interurban passenger transit, 42 - Motor freight transportation and warehousing, 43 - U.S. Postal Service, 44 - Water transportation, 45 - Transportation by air, 46 - Pipelines, except natural gas, 47 - Transportation services, 48 - Communications, 49 - Electric, gas, and sanitary services' }],
                ['I32', { 'value': '4/1/2020' }],
            ],
            'literals': [
                {
                    'template': [3, 25],
                    'data': [
                        {
                            'companyName': 'Alaska West Express',
                            'address': 'Mile 4 Captain Bays Rd',
                            'city': 'Dutch Harbor',
                            'state': 'AK',
                            'zipCode': '99692',
                            'website': 'http://northlandservices.com',
                            'ticketSymbol': '',
                            'parent': 'Northland Services, Inc.',
                            'benefitSponsor': 'N',
                            'yearEstablished': '',
                            'dunsDUNS': '053816245',
                            'naicsCode': '483211',
                            'naicsNAICS': 'Inland Water Freight Transportation',
                            'sicCode': '4449',
                            'sicDescription': 'Water Transportation of Freight, NEC',
                            'fortuneRank': 675,
                            'totalEmployees': 6541,
                            'employeesAtCurrent': 304,
                            'revenue': 63100000,
                            'finanacialStress': '',
                            'commercialCredit': '',
                            'paydex': '',
                            'growth3yr': '',
                            'growth5yr': '',
                        },
                        {
                            'companyName': 'Alaska West Express 22',
                            'address': 'Mile 4 Captain Bays Rd',
                            'city': 'Dutch Harbor',
                            'state': 'AK',
                            'zipCode': '99692',
                            'website': 'http://northlandservices.com',
                            'ticketSymbol': '',
                            'parent': 'Northland Services 22, Inc.',
                            'benefitSponsor': 'N',
                            'yearEstablished': '',
                            'dunsDUNS': '053816245',
                            'naicsCode': '483211',
                            'naicsNAICS': 'Inland Water Freight Transportation',
                            'sicCode': '4449',
                            'sicDescription': 'Water Transportation of Freight, NEC',
                            'fortuneRank': 675,
                            'totalEmployees': 6541,
                            'employeesAtCurrent': 304,
                            'revenue': 631099999,
                            'finanacialStress': '',
                            'commercialCredit': '',
                            'paydex': '',
                            'growth3yr': '',
                            'growth5yr': '',
                        },
                    ]
                }
            ]
        },
    ]
});



