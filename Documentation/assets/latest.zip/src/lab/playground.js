const _ = require('lodash');

const splitAt = index => x => [x.slice(0, index), x.slice(index)]

const alphabetToDecimal = val => {
    const offset = 64;
    const len = val.length - 1;
    return val
        .split('')
        .map(c => c.charCodeAt(0) - offset)
        .reduce((p, c, i) => p += c * 26 ** (len - i), 0);
}

const decimalToAlphabet = val => {
    const offset = 64;
    const str = []
    while (val != 0) {
        let tmp = val % 26;
        val = Math.floor(val / 26);
        if (tmp === 0) {
            tmp = 26;
            val -= 1;
        }
        str.push(String.fromCharCode(tmp + offset));
    }
    return str.reverse().join('');
}

const getCells = (a, b) => {
    a = a.toUpperCase(), b = b.toUpperCase();
    const [col1, row1] = splitAt(a.search(/\d/))(a);
    const [col2, row2] = splitAt(b.search(/\d/))(b);
    const ans = [];
    for (let c = alphabetToDecimal(col1); c <= alphabetToDecimal(col2); c++) {
        for (let r = _.toNumber(row1); r <= _.toNumber(row2); r++) {
            ans.push(decimalToAlphabet(c) + r);
        }
    }
    return ans;
}

console.log(getCells(
    'AA20', 'AD22'
))
// console.log(alphabetToDecimal('AMK'));
// console.log(decimalToAlphabet(1025));

/*
aac -> 1*26*26+1*26+3
*/