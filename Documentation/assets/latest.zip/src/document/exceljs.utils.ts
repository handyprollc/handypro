import _ from 'lodash';

export class ExcelJSUtils {
    public static alphabetToDecimal(val: string): number {
        const offset = 64;
        const len = val.length - 1;
        return val
            .split('')
            .map(c => c.charCodeAt(0) - offset)
            .reduce((p, c, i) => p += c * 26 ** (len - i), 0);
    }

    public static decimalToAlphabet(val: number): string {
        const offset = 64;
        const str = [];
        while (val !== 0) {
            let tmp = val % 26;
            val = Math.floor(val / 26);
            if (tmp === 0) {
                tmp = 26;
                val -= 1;
            }
            str.push(String.fromCharCode(tmp + offset));
        }
        return str.reverse().join('');
    }

    static splitAt = (index: number) => (x: string): string[] => [x.slice(0, index), x.slice(index)];

    public static getCellsInRange(a: string, b: string): string[] {
        a = a.toUpperCase(), b = b.toUpperCase();
        const [col1, row1] = this.splitAt(a.search(/\d/))(a);
        const [col2, row2] = this.splitAt(b.search(/\d/))(b);
        const ans = [];
        for (let c = ExcelJSUtils.alphabetToDecimal(col1); c <= ExcelJSUtils.alphabetToDecimal(col2); c++) {
            for (let r = _.toNumber(row1); r <= _.toNumber(row2); r++) {
                ans.push(ExcelJSUtils.decimalToAlphabet(c) + r);
            }
        }
        return ans;
    }

}
