export const companyPayload = {
    'template': 'employer-search:BenefitSponsorReport.xlsx',
    'data': [
        {
            'sheet': 'Sheet1',
            'rows': [
                [
                    6,
                    [
                        ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
                        ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
                        ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
                        ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002],
                        ['American Family Care Inc.', '', '', '3700 Cahaba Beach RdBirmingham,AL, 35242', '62', 'Health Care and Social Assistance', '8011', 'Offices and Clinics of Doctors of Medicine', 'AL - BCBS', 'Y', 212, 790, 1002]
                    ]
                ]
            ],
            'cells': [
                ['C12', { 'value': '4/15/2015' }],
                ['C14', { 'value': '4/1/2020' }],
                ['C16', { 'value': '4/1/2020' }],
                ['C18', { 'value': 'DE - Highmark BCBS,PA - Highmark BCBS,PA - Highmark BS,WV - Highmark BCBS' }],
                ['H14', { 'value': '4/1/2020' }],
                ['H16', { 'value': '40 - Railroad Transportation, 41 - Local and interurban passenger transit, 42 - Motor freight transportation and warehousing, 43 - U.S. Postal Service, 44 - Water transportation, 45 - Transportation by air, 46 - Pipelines, except natural gas, 47 - Transportation services, 48 - Communications, 49 - Electric, gas, and sanitary services' }],
                ['M22', { 'value': '4/1/2020' }],
            ]
        }
    ]
};