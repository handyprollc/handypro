import { TabularData } from '@app/common/scalars/tabularData';
import { BadRequestException, Body, Controller, Header, Logger, Post, Res } from '@nestjs/common';
import { Response } from 'express';
import fs from 'fs';
import { join } from 'path';
import { DocumentService } from './document.service';

const ROOT_DIR = join(__dirname, '..', '..');

@Controller('document')
export class DocumentResolver {

  protected readonly logger = new Logger('DocumentResolver');

  constructor(private readonly documentService: DocumentService) { }

  @Post('generateExcel')
  @Header(
    'Content-Type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  )
  @Header(
    'Cache-Control',
    'no-cache'
  )
  async generateExcel(
    @Body() body: any,
    @Res() res: Response,) {
    const { template, data } = body;
    if (!template || !data) throw new BadRequestException();
    const [app, filename] = template.split(':');
    const path = join(ROOT_DIR, 'templates', app, filename);
    if (!fs.existsSync(path)) throw new BadRequestException(`Template[${path}] not found!`);
    const buff = await this.documentService.generateExcel({ path, data });
    res.set({
      'Content-Length': buff.byteLength,
      'Content-Disposition': 'attachment; filename=' + filename
    });
    res.send(buff);
  }

  @Post('renderTabularData')
  @Header(
    'Content-Type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  )
  @Header(
    'Cache-Control',
    'no-cache'
  )
  async renderTabularData(
    @Body() body: TabularData,
    @Res() res: Response,) {
    const { columns, rows } = body;
    const path = join(ROOT_DIR, 'templates', 'blank.xlsx');
    if (!fs.existsSync(path)) throw new BadRequestException(`Template[${path}] not found!`);
    const buff = await this.documentService.generateExcel({
      path,
      data: [
        {
          sheet: 'Sheet1',
          rows: [
            [
              1,
              [
                columns,
                ...rows
              ]
            ]
          ]
        }
      ]
    });
    res.set({
      'Content-Length': buff.byteLength,
      'Content-Disposition': `attachment; filename=response_${Date.now()}.xlsx`
    });
    res.send(buff);
  }

}