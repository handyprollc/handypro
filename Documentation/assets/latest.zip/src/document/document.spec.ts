import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DocumentModule } from './document.module';
import { DocumentResolver } from './document.resolver';
import { DocumentService } from './document.service';

describe('Document Module', () => {
  let app: INestApplication;
  let documentResolver: DocumentResolver;
  let documentService: DocumentService;

  beforeAll(async () => {
    const mod = await Test.createTestingModule({
      imports: [DocumentModule],
    }).compile();
    app = mod.createNestApplication();
    await app.init();
    documentResolver = mod.get<DocumentResolver>(DocumentResolver);
    documentService = mod.get<DocumentService>(DocumentService);
  });

  describe('generateExcel', () => {
    it('generateExcel', async () => {
      return request(app.getHttpServer())
        .get('/cats')
        .expect(404);
    });
  });

  afterAll(async () => {
    await app.close();
  });

});
