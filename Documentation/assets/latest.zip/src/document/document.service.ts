import { Injectable, Logger } from '@nestjs/common';
import Excel, { Cell } from 'exceljs';
import _ from 'lodash';

@Injectable()
export class DocumentService {
  private readonly logger = new Logger('DocumentService');

  private fillCell(cell: Cell, value: any) {
    if (!cell || !value) return;
    if (value.hasOwnProperty('value') || value.hasOwnProperty('text'))
      Object.keys(value).forEach(k => cell[k] = value[k]);
    else
      cell.value = value;
  }

  private getLiteralValue(context: any, v: any) {
    if (_.isString(v)) {
      const match = (/\${([^}]+)}/g).exec(v);
      if (!_.isEmpty(match)) {
        const key = match[1];
        return context[key] || '';
      }
    }
    return v;
  }

  public async generateExcel({ path, data }): Promise<Excel.Buffer> {
    const xlsx = new Excel.Workbook().xlsx;
    const tmpl = await xlsx.readFile(path);
    if (_.isEmpty(data)) return xlsx.writeBuffer();
    for (const { sheet, rows, cells, literals } of data) {
      const ws = tmpl.getWorksheet(sheet);
      if (!ws) {
        this.logger.warn(`Sheet[${sheet}] is not found in : ${path}`);
        continue;
      }
      if (!_.isEmpty(cells)) {
        for (const [ref, it] of cells) {
          const cell = ws.getCell(ref);
          this.fillCell(cell, it);
        }
      }
      if (!_.isEmpty(rows)) {
        for (const [ref, rowVals] of rows) {
          const l = rowVals.length;
          const w = rowVals[0].length;
          const placeholder = Array.from(Array(l), () =>
            Array(w).fill('')
          );
          ws.spliceRows(ref, 0, ...placeholder);
          for (let row = ref; row < ref + l; row++) {
            let col = 0;
            ws.getRow(row).eachCell((cell) => {
              const it = rowVals[row - ref][col++];
              this.fillCell(cell, it);
            });
          }
        }
      }
      if (!_.isEmpty(literals)) {
        for (const { template: [r1, r2], data: vals } of literals) {
          const rowsSrc = _.range(r1, r2).map(r => ws.getRow(r));
          ws.spliceRows(r2 + 1, 0, ...new Array((r2 - r1) * vals.length).fill(''));
          vals.forEach((val, i) => {
            rowsSrc.forEach((rSrc, rOffset) => {
              const rDstNum = r2 + i * rowsSrc.length + rOffset;
              const rDst = ws.getRow(rDstNum);
              if (_.isArray(rSrc.values)) {
                const inserts = rSrc.values.map(v => this.getLiteralValue(val, v));
                rDst.values = inserts;
                rDst.height = rSrc.height;
                rSrc.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                  rDst.getCell(colNumber).style = cell.style;
                });
              }
            });
          });
          ws.spliceRows(r1, r2 - r1);
        }
      }
    }
    return xlsx.writeBuffer();
  }
}
