import { Carrier } from '@app/carrier/carrier.entity.pg.fdm';
import { CarrierResolver } from '@app/carrier/carrier.resolver';
import { CarrierService } from '@app/carrier/carrier.service';
import { PG_FDM } from '@app/common/constants';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([Carrier], PG_FDM)],
  providers: [CarrierResolver, CarrierService],
  exports: [CarrierService],
})
export class CarrierModule { }
