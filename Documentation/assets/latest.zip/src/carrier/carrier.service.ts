import { Carrier } from '@app/carrier/carrier.entity.pg.fdm';
import { PG_FDM } from '@app/common/constants';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class CarrierService {
  constructor(
    @InjectRepository(Carrier, PG_FDM)
    private readonly carrierRepo: Repository<Carrier>,
  ) { }

  async getCarrier(id: any): Promise<Carrier> {
    id = id instanceof String ? Number.parseInt(id as string, 0) : id as number;
    return await this.carrierRepo.findOne(id);
  }

  async getRestrictedCarriers(carrierId: number): Promise<Carrier[]> {
    const carrier = await this.getCarrier(carrierId);
    return carrier.restrictedCarriers;
  }

  async findCarriers(): Promise<Carrier[]> {
    return await this.carrierRepo.find();
  }
}
