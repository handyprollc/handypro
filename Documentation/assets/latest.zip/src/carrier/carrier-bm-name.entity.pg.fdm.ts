import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType()
@Entity('benchmark_names', { schema: 'carriers' })
export class BenchmarkingName {
    @Field()
    @PrimaryGeneratedColumn()
    readonly carrier: number;
    @Field({ nullable: true })
    @Column()
    name: string;
}
