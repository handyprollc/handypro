import { Carrier } from '@app/carrier/carrier.entity.pg.fdm';
import { CarrierService } from '@app/carrier/carrier.service';
import { Args, Query, Resolver } from '@nestjs/graphql';

@Resolver('Carrier')
export class CarrierResolver {
  constructor(private readonly carrierService: CarrierService) {}

  @Query(returns => [Carrier], { name: 'carrier_restrictedCarriers' })
  restrictedCarriers(@Args('id') id: number): Promise<Carrier[]> {
    return this.carrierService.getRestrictedCarriers(id);
  }

  @Query(returns => [Carrier], { name: 'carrier_carriers' })
  carriers(): Promise<Carrier[]> {
    return this.carrierService.findCarriers();
  }

  @Query(returns => Carrier, { name: 'carrier_carrier' })
  carrier(@Args('id') id: number): Promise<Carrier> {
    return this.carrierService.getCarrier(id);
  }
}
