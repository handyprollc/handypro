import { BenchmarkingName } from '@app/carrier/carrier-bm-name.entity.pg.fdm';
import { CarrierGroup } from '@app/carrier/carrier-group.entity.pg.fdm';
import { State } from '@app/geography/state.entity.pg.fdm';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';

@ObjectType()
@Entity('carriers', { schema: 'carriers' })
export class Carrier {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
    @Field({ nullable: true })
    @Column()
    type: number;
    @Field({ nullable: true })
    @Column()
    marketName: string;
    @Field({ nullable: true })
    @Column()
    description: string;
    @Field({ nullable: true })
    @Column({ name: 'group' })
    groupId: number;
    @Field(type => CarrierGroup, { nullable: true })
    @ManyToOne(type => CarrierGroup, { lazy: true })
    @JoinColumn({ name: 'group' })
    group: CarrierGroup;
    @Field(type => State, { nullable: true })
    @ManyToOne(type => State, { lazy: true })
    @JoinColumn({ name: 'state' })
    state: State;
    @Field(type => BenchmarkingName, { nullable: true })
    @ManyToOne(type => BenchmarkingName, { lazy: true })
    @JoinColumn({ name: 'id' })
    benchmarkingName: BenchmarkingName;
    @Field(type => [Carrier], { nullable: true })
    @ManyToMany(type => Carrier, { lazy: true })
    @JoinTable({
        schema: 'whsusr',
        name: 'iq_plan_restrict',
        joinColumn: {
            name: 'user_ca_id',
            referencedColumnName: 'id'
        },
        inverseJoinColumn: {
            name: 'ca_id',
            referencedColumnName: 'id'
        },
    })
    // @JoinTable({
    //     database: DB_DATAMART,
    //     schema: 'benchmarking',
    //     name: 'blinded_carriers',
    //     joinColumn: {
    //         name: 'carrier_group',
    //         referencedColumnName: 'group',
    //     },
    //     inverseJoinColumn: {
    //         name: 'blinded_carrier',
    //         referencedColumnName: 'id',
    //     }
    // })
    restrictedCarriers: Carrier[];
}
