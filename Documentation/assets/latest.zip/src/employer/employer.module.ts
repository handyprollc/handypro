import { PG_FDM } from '@app/common/constants';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Company } from './company.entity.pg.fdm';
import { EmployerResolver } from './employer.resolver';
import { EmployerService } from './employer.service';
import { RequestLog } from './requestLog.entity.pg.fdm';



@Module({
  imports: [TypeOrmModule.forFeature([Company, RequestLog], PG_FDM)],
  providers: [EmployerResolver, EmployerService],
  exports: [EmployerService],
})
export class EmployerModule { }
