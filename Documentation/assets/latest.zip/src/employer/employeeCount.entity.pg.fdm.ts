import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@ObjectType('Employer_EmployeeCount')
@Entity('du_employee_counts', { schema: 'employer' })
export class EmployeeCount {
    @Field({ nullable: true }) @Column() provider: string;
    @Field({ nullable: true }) @PrimaryColumn() domesticUltimate: number;
    @Field({ nullable: true }) @Column() carrierGroupCode: number;
    @Field({ nullable: true }) @Column() employees: number;
}