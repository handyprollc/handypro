import { Carrier } from '@app/carrier/carrier.entity.pg.fdm';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { Company } from './company.entity.pg.fdm';

@ObjectType('Employer_CompanyBranch')
@Entity('company_branch', { schema: 'employer' })
export class CompanyBranch {
    @Field({ nullable: true }) @PrimaryColumn() branch: number;
    @Field({ nullable: true }) @Column() branchEmployeeRollupCh: number;
    @Field({ nullable: true }) @Column() company: number;
    @Field({ nullable: true }) @Column() companyName: string;
    @Field({ nullable: true }) @Column() provider: string;
    @Field({ nullable: true }) @Column() stateAbbreviation: string;
    @Field(type => Carrier, { nullable: true })
    @ManyToOne(type => Carrier, { lazy: true })
    @JoinColumn({ name: 'carrierCode' })
    carrier: Carrier;
    @Field(type => Company, { nullable: true })
    @ManyToOne(type => Company, { lazy: true })
    @JoinColumn({ name: 'company', referencedColumnName: 'company' })
    parent: Company;

}