import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('request_log', { schema: 'employer' })
export class RequestLog {
    @PrimaryGeneratedColumn() id: number;
    @Column({ nullable: false, name: 'usr' }) user: string;
    @Column({ nullable: false, name: 'grp', }) group: string;
    @Column({ nullable: false, }) report: string;
    @Column({ nullable: false }) params: string;
    @CreateDateColumn({ type: 'timestamp without time zone' })
    requestTime: Date;
    @Column({ nullable: false }) version: number;

    // @BeforeInsert()
    // beforeInsert(): void {
    //     this.version = 0;
    //     this.group = 'employer_search';
    //     this.requestTime = new Date();
    // }

}