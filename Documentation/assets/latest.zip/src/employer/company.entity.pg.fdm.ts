import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { EmployeeCount } from './employeeCount.entity.pg.fdm';

@ObjectType('Employer_Company')
@Entity('company', {  schema: 'employer' })
export class Company {
    @Field({ nullable: true }) @Column() provider: string;
    @Field({ nullable: true }) @PrimaryColumn() company: number;
    @Field({ nullable: true }) @Column() dunsNumber: string;
    @Field({ nullable: true }) @Column() decisionMakerCode: string;
    @Field({ nullable: true }) @Column() companyName: string;
    @Field({ nullable: true }) @Column() companyCountryName: string;
    @Field({ nullable: true }) @Column({ name: 'company_address_1' }) companyAddress1: string;
    @Field({ nullable: true }) @Column() companyCity: string;
    @Field({ nullable: true }) @Column() companyState: string;
    @Field({ nullable: true }) @Column() companyZip: string;
    @Field({ nullable: true }) @Column() globalUltimate: number;
    @Field({ nullable: true }) @Column() domesticUltimate: number;
    @Field({ nullable: true }) @Column() parentDuns: string;
    @Field({ nullable: true }) @Column() companyLevel: number;
    @Field({ nullable: true }) @Column({ name: 'fortune_1000_rank' }) fortune1000Rank: number;
    @Field({ nullable: true }) @Column() yearStarted: number;
    @Field({ nullable: true }) @Column() parentName: string;
    @Field({ nullable: true }) @Column() domesticUltimateName: string;
    @Field({ nullable: true }) @Column() primaryStockSymbol: string;
    @Field({ nullable: true }) @Column() companyWebsite: string;
    @Field({ nullable: true }) @Column() commercialCreditScore: string;
    @Field({ nullable: true }) @Column() paydexScore: string;
    @Field({ nullable: true }) @Column() financialStressScore: string;
    @Field({ nullable: true }) @Column() carrierCode: number;
    @Field({ nullable: true }) @Column() carrierName: string;
    @Field({ nullable: true }) @Column() carrierTypeName: string;
    @Field({ nullable: true }) @Column() carrierTypeCode: number;
    @Field({ nullable: true }) @Column() naicsNationalName: string;
    @Field({ nullable: true }) @Column() naicsNationalCode: string;
    @Field({ nullable: true }) @Column() naicsIndustryName: string;
    @Field({ nullable: true }) @Column() naicsIndustryCode: number;
    @Field({ nullable: true }) @Column() naicsGroupName: string;
    @Field({ nullable: true }) @Column() naicsGroupCode: number;
    @Field({ nullable: true }) @Column() naicsSubsectorName: string;
    @Field({ nullable: true }) @Column() naicsSubsectorCode: number;
    @Field({ nullable: true }) @Column() naicsSectorName: string;
    @Field({ nullable: true }) @Column() naicsSectorCode: string;
    @Field({ nullable: true }) @Column() sicIndustryName: string;
    @Field({ nullable: true }) @Column() sicIndustryCode: string;
    @Field({ nullable: true }) @Column() sicIndustryGroupName: string;
    @Field({ nullable: true }) @Column() sicIndustryGroupCode: string;
    @Field({ nullable: true }) @Column() sicMajorGroupCode: string;
    @Field({ nullable: true }) @Column() sicMajorGroupName: string;
    @Field({ nullable: true }) @Column() sicDivisionName: string;
    @Field({ nullable: true }) @Column() sicDivisionCode: string;
    @Field({ nullable: true }) @Column() stateName: string;
    @Field({ nullable: true }) @Column() stateFips: string;
    @Field({ nullable: true }) @Column() dataAsOf: Date;
    @Field({ nullable: true }) @Column() adjDomEmployeesHere: number;
    @Field({ nullable: true }) @Column() adjDomEmployeesRollup: number;
    @Field({ nullable: true }) @Column() adjDomEmployeesTotal: number;
    @Field({ nullable: true }) @Column() companySales: number;
    @Field({ nullable: true }) @Column({ name: 'company_pct_gr_sales_3_yr' }) companyPctGrSales3Yr: number;
    @Field({ nullable: true }) @Column({ name: 'company_pct_gr_sales_5_yr' }) companyPctGrSales5Yr: number;
    @Field({ nullable: true }) @Column() domesticUltimateCarrierName: string;
    @Field({ nullable: true }) @Column() domesticUltimateCarrierCode: string;
    @Field({ nullable: true }) @Column() employeeBand: number;
    @Field({ nullable: true }) @Column() fortuneBand: number;
    @Field({ nullable: true }) @Column() duChpMember: string;
    @Field({ nullable: true }) @Column() stakeholderCode: string;
    @Field(type => EmployeeCount, { nullable: true })
    @ManyToOne(type => EmployeeCount)// { eager: true }
    @JoinColumn({ name: 'company', referencedColumnName: 'domesticUltimate' })
    employeeCount: EmployeeCount;
}