import { EmployerSearchUsageInterceptor } from '@app/common/interceptor/usage.interceptor';
import { AuthGuard } from '@app/security/auth.guard';
import { Logger, UseGuards, UseInterceptors } from '@nestjs/common';
import { Args, Query, Resolver } from '@nestjs/graphql';
import { Company } from './company.entity.pg.fdm';
import { CompanyBranch } from './companyBranch.entity.pg.fdm';
import { EmployeesByCarrier } from './employeesByCarrier';
import { EmployerService } from './employer.service';

@Resolver('Employer')
export class EmployerResolver {
  protected readonly logger = new Logger('EmployerResolver');

  constructor(private readonly employerService: EmployerService) { }

  @Query(returns => [Company], { name: 'employer_companies' })
  @UseGuards(AuthGuard)
  @UseInterceptors(EmployerSearchUsageInterceptor)
  queryCompanies(
    @Args({ name: 'reportName', type: () => String })
    reportName: string,
    @Args({ name: 'companyIds', type: () => [Number], nullable: true })
    companyIds: number[],
    @Args({ name: 'carriers', type: () => [Number], nullable: true })
    carriers: number[],
    @Args({ name: 'states', type: () => [String], nullable: true })
    states: string[],
    @Args({ name: 'naicsSectors', type: () => [Number], nullable: true })
    naicsSectors: number[],
    @Args({ name: 'naicsCodes', type: () => [Number], nullable: true })
    naicsCodes: number[],
    @Args({ name: 'sicDivisions', type: () => [String], nullable: true })
    sicDivisions: string[],
    @Args({ name: 'sicCodes', type: () => [String], nullable: true })
    sicCodes: string[],
    @Args({ name: 'fortuneRankBand', type: () => Number, nullable: true })
    fortuneRankBand: number,
    @Args({ name: 'employeeCountBand', type: () => Number, nullable: true })
    employeeCountBand: number,
    @Args({ name: 'keyword', type: () => String, nullable: true })
    keyword: string,
    @Args({ name: 'country', type: () => String, nullable: true })
    country: string,
    @Args({ name: 'benefitSponsors', type: () => Boolean, nullable: true })
    benefitSponsors: boolean,
  ): Promise<Company[]> {
    return this.employerService.queryCompanies({
      reportName,
      companyIds,
      carriers,
      states,
      naicsSectors,
      naicsCodes,
      sicDivisions,
      sicCodes,
      fortuneRankBand,
      employeeCountBand,
      keyword,
      country,
      benefitSponsors,
    });
  }

  @Query(returns => [Company], { name: 'employer_groupCompanies' })
  @UseGuards(AuthGuard)
  getGroupCompanies(
    @Args({ name: 'id', type: () => Number })
    id: number,
  ): Promise<Company[]> {
    return this.employerService.getGroupCompanies(id);
  }

  @Query(returns => [CompanyBranch], { name: 'employer_companyBranch' })
  @UseGuards(AuthGuard)
  getCompanyBranches(
    @Args({ name: 'id', type: () => Number })
    id: number,
  ): Promise<CompanyBranch[]> {
    return this.employerService.getCompanyBranches(id);
  }

  @Query(returns => [EmployeesByCarrier], { name: 'employer_employeesByCarrier' })
  @UseGuards(AuthGuard)
  countEmployeesByCarrier(
    @Args({ name: 'id', type: () => Number })
    id: number,
  ): Promise<EmployeesByCarrier[]> {
    return this.employerService.countEmployeesByCarrier(id);
  }
}
