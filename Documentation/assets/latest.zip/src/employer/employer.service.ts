import { PG_FDM } from '@app/common/constants';
import { Injectable, Logger } from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import * as _ from 'lodash';
import { EntityManager } from 'typeorm';
import { Company } from './company.entity.pg.fdm';
import { CompanyBranch } from './companyBranch.entity.pg.fdm';
import { EmployeesByCarrier } from './employeesByCarrier';
import { RequestLog } from './requestLog.entity.pg.fdm';

@Injectable()
export class EmployerService {
  protected readonly logger = new Logger('EmployerService');

  constructor(
    @InjectEntityManager(PG_FDM)
    private readonly em: EntityManager,
  ) { }

  queryCompanies(criteria: ReportCriteria): Promise<Company[]> {
    const qb = this.em.createQueryBuilder(Company, 'c')
      .innerJoinAndSelect('c.employeeCount', 'ct', 'ct.employees > 0');
    const {
      companyIds,
      carriers,
      states,
      naicsSectors,
      naicsCodes,
      sicDivisions,
      sicCodes,
      fortuneRankBand,
      employeeCountBand,
      keyword,
      country,
      benefitSponsors,
    } = criteria;
    if (!_.isEmpty(companyIds)) qb.andWhere('c.company IN (:...companyIds)', { companyIds });
    if (!_.isEmpty(carriers)) qb.andWhere('c.carrierCode IN (:...carriers)', { carriers });
    if (!_.isEmpty(states)) qb.andWhere('c.companyState IN (:...states)', { states });
    if (!_.isEmpty(naicsSectors)) qb.andWhere('c.naicsSectorCode IN (:...naicsSectors)', { naicsSectors });
    if (!_.isEmpty(naicsCodes)) qb.andWhere('c.naicsNationalCode IN (:...naicsCodes)', { naicsCodes });
    if (!_.isEmpty(sicDivisions)) qb.andWhere('c.sicDivisionCode IN (:...sicDivisions)', { sicDivisions });
    if (!_.isEmpty(sicCodes)) qb.andWhere('c.sicIndustryCode IN (:...sicCodes)', { sicCodes });
    if (!!fortuneRankBand) qb.andWhere('c.fortuneBand = :fortuneRankBand', { fortuneRankBand });
    if (!!employeeCountBand) qb.andWhere('c.employeeBand = :employeeCountBand', { employeeCountBand });
    if (!!keyword) qb.andWhere('LOWER(c.companyName) LIKE :keyword', { keyword: `%${keyword.toLowerCase()}%` });
    if (!!country) qb.andWhere('c.companyCountryName = :country', { country });
    if (!!benefitSponsors) qb.andWhere('c.decisionMakerCode = :decisionMakerCode', { decisionMakerCode: 'D' });

    return qb
      .orderBy('c.companyName')
      .addOrderBy('c.carrierCode')
      // .take(1000)
      .getMany();


    // let where = {};
    // if (!!criteria.companyIds) where = { ...where, company: In(criteria.companyIds) };
    // if (!!criteria.carriers) where = { ...where, carrierCode: In(criteria.carriers) };
    // if (!!criteria.states) where = { ...where, companyState: In(criteria.states) };
    // if (!!criteria.naicsSectors) where = { ...where, naicsSectorCode: In(criteria.naicsSectors) };
    // if (!!criteria.naicsCodes) where = { ...where, naicsNationalCode: In(criteria.naicsCodes) };
    // if (!!criteria.sicDivisions) where = { ...where, sicDivisionCode: In(criteria.sicDivisions) };
    // if (!!criteria.sicCodes) where = { ...where, sicIndustryCode: In(criteria.sicCodes) };
    // if (!!criteria.fortuneRankBand) where = { ...where, fortuneBand: criteria.fortuneRankBand };
    // if (!!criteria.employeeCountBand) where = { ...where, employeeBand: criteria.employeeCountBand };
    // return this.em.getRepository(Company).find({
    //   join: {
    //     alias: 'c',
    //     innerJoinAndSelect: {
    //       ct: 'c.employeeCount'
    //     }
    //   },
    //   where,
    //   take: 200,
    //   order: {
    //     companyName: 'ASC',
    //     carrierCode: 'ASC',
    //   }
    // });
  }

  getGroupCompanies(id: number): Promise<Company[]> {
    return this.em
      .createQueryBuilder(Company, 'co')
      .where(qb => {
        const subQuery = qb.subQuery()
          .select('DISTINCT c.globalUltimate')
          .from(Company, 'c')
          .where('c.company = :id')
          .getQuery();
        return 'co.global_ultimate IN ' + subQuery;
      })
      .setParameter('id', id)
      .orderBy('co.companyLevel')
      .getMany();
  }
  getCompanyBranches(id: number): Promise<CompanyBranch[]> {
    return this.em
      .createQueryBuilder(CompanyBranch, 'br')
      .innerJoinAndSelect('br.parent', 'co')
      .innerJoinAndSelect('br.carrier', 'car')
      .where('co.domesticUltimate = :id', { id })
      .getMany();
  }

  countEmployeesByCarrier(id: number): Promise<EmployeesByCarrier[]> {
    return this.em
      .createQueryBuilder(CompanyBranch, 'br')
      .innerJoinAndSelect('br.parent', 'co')
      .innerJoinAndSelect('br.carrier', 'car')
      .select('car.name', 'carrier')
      .addSelect('br.state_abbreviation', 'state')
      .addSelect('SUM(br.branchEmployeeRollupCh)', 'employees')
      .where('co.domesticUltimate = :id', { id })
      .groupBy('car.name')
      .addGroupBy('br.state_abbreviation')
      .orderBy('car.name')
      .getRawMany();
  }

  logUsage(user: string, params: ReportCriteria) {
    const usage = {
      user,
      report: params.reportName,
      params: JSON.stringify(params),
      requestTime: new Date(),
      group: 'employer_search',
      version: 1,
    };
    this.em.getRepository(RequestLog).insert(usage);
  }
}

interface ReportCriteria {
  reportName: string,
  companyIds?: number[],
  carriers?: number[],
  states?: string[],
  naicsSectors?: number[],
  naicsCodes?: number[],
  sicDivisions?: string[],
  sicCodes?: string[],
  fortuneRankBand?: number,
  employeeCountBand?: number,
  keyword?: string,
  country?: string,
  benefitSponsors?: boolean,
}