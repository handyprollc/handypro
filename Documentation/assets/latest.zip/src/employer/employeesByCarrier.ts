import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType('Employer_EmployeesByCarrier')
export class EmployeesByCarrier {
    @Field() carrier: string;
    @Field() state: string;
    @Field() employees: number;
}
