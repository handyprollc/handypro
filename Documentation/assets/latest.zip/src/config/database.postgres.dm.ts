import connection from './database.postgres';

export default () => ({
    ...connection(),
    database: process.env.DB_DM,
    entities: [__dirname + '/../**/*.entity.pg.dm.{ts,js}'],
});