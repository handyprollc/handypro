import { SnakeNamingStrategy } from '@app/orm/config/naming-strategy';

export default () => ({
    type: 'mssql',
    host: process.env.DB_MSSQL_HOST,
    username: process.env.DB_MSSQL_USERNAME,
    password: process.env.DB_MSSQL_PASSWORD,
    port: +process.env.DB_MSSQL_PORT,
    // extra: {
    //     domain: 'PROLIANT4500NT'
    // },
    synchronize: false,
    logger: 'advanced-console',
    logging: 'all',
    cache: true,
    namingStrategy: new SnakeNamingStrategy(),
    entities: [__dirname + '/../**/*.entity.ms.{ts,js}'],
});