import MSSQL from './database.mssql';
import PG_DATAMART from './database.postgres.datamart';
import PG_DM from './database.postgres.dm';
import PG_FDM from './database.postgres.fdm';


export default [() => ({
    MSSQL,
    PG_DATAMART,
    PG_DM,
    PG_FDM,
})];
