import connection from './database.postgres';

export default () => ({
    ...connection(),
    database: process.env.DB_DATAMART,
    entities: [__dirname + '/../**/*.entity.pg.datamart.{ts,js}'],
});