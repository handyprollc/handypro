import { SnakeNamingStrategy } from '../orm/config/naming-strategy';

export default () => ({
    type: 'postgres',
    host: process.env.DB_POSTGRES_HOST,
    username: process.env.DB_POSTGRES_USERNAME,
    password: process.env.DB_POSTGRES_PASSWORD,
    port: +process.env.DB_POSTGRES_PORT,
    synchronize: false,
    logger: 'advanced-console',
    logging: 'all',
    cache: true,
    namingStrategy: new SnakeNamingStrategy(),
});
