import connection from './database.postgres';

export default () => ({
    ...connection(),
    database: process.env.DB_FDM,
    entities: [__dirname + '/../**/*.entity.pg.fdm.{ts,js}'],
});