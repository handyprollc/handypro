import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('GEO_Region')
@Entity('regions', { schema: 'geography' })
export class Region {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
}
