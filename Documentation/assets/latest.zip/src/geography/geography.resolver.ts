import { Query, Resolver } from '@nestjs/graphql';
import { GeographyService } from './geography.service';
import { State } from './state.entity.pg.fdm';

@Resolver('Geography')
export class GeographyResolver {
  constructor(private readonly geoService: GeographyService) { }

  @Query(returns => [State], { name: 'geo_states' })
  listState(): Promise<State[]> {
    return this.geoService.listState();
  }
}
