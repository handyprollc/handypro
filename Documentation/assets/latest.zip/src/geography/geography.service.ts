import { PG_FDM } from '@app/common/constants';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { State } from './state.entity.pg.fdm';

@Injectable()
export class GeographyService {
  constructor(
    @InjectRepository(State, PG_FDM)
    private readonly stateRepo: Repository<State>,
  ) { }

  public async listState(): Promise<State[]> {
    return this.stateRepo.find();
  }
}