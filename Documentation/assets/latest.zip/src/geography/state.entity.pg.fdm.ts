import { Division } from '@app/geography/divison.entity.pg.fdm';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('GEO_State')
@Entity('states', { schema: 'geography' })
export class State {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
    @Field({ nullable: true })
    @Column()
    abbreviation: string;
    @Field({ nullable: true })
    @Column({ name: 'division' })
    divisionId: number;
    @Field(type => Division, { nullable: true })
    @ManyToOne(type => Division, divison => divison.id, { lazy: true })
    @JoinColumn({ name: 'division' })
    division: Division;
}
