import { State } from '@app/geography/state.entity.pg.fdm';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('GEO_County')
@Entity('counties', { schema: 'geography' })
export class County {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
    @Field(type => State, { nullable: true })
    @ManyToOne(type => State, { lazy: true })
    @JoinColumn({ name: 'state' })
    state: State;
}
