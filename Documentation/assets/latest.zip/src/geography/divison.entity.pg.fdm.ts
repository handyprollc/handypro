import { Region } from '@app/geography/region.entity.pg.fdm';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';

@ObjectType('GEO_Division')
@Entity('divisions', { schema: 'geography' })
export class Division {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
    @Field(type => Region, { nullable: true })
    @ManyToOne(type => Region, { lazy: true })
    @JoinColumn({ name: 'region' })
    region: Region;
}
