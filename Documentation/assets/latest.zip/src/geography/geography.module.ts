import { PG_FDM } from '@app/common/constants';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GeographyResolver } from './geography.resolver';
import { GeographyService } from './geography.service';
import { State } from './state.entity.pg.fdm';

@Module({
  imports: [TypeOrmModule.forFeature([State], PG_FDM)],
  providers: [GeographyService, GeographyResolver],
  exports: [GeographyService],
})
export class GeographyModule { }
