import { DB_BENCHMARKING } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('BenchmarkingName2')
@Entity('benchmark_names', { database: DB_BENCHMARKING, schema: 'carriers' })
export class BenchmarkingName {
    @Field()
    @PrimaryGeneratedColumn()
    readonly carrier: number;
    @Field({ nullable: true })
    @Column()
    name: string;
}
