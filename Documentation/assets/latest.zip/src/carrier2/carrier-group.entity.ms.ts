import { DB_BENCHMARKING } from '@app/common/constants';
import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';


@ObjectType('CarrierGroup2')
@Entity('groups', { database: DB_BENCHMARKING, schema: 'carriers' })
export class CarrierGroup {
    @Field()
    @PrimaryGeneratedColumn()
    readonly id: number;
    @Field({ nullable: true })
    @Column()
    name: string;
}
