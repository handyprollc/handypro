module.exports = {
    apps: [{
        name: 'insights-service',
        script: 'dist/main.js',
        instances: "max",
        exec_mode: "cluster",
        autorestart: true,
        watch: false,
        max_memory_restart: '4G',
        timestamp: "MM-DD-YYYY HH:mm Z",
        log_date_format: "MM-DD-YYYY HH:mm Z",
        error_file: "./logs/insights-service-stderr.log",
        out_file: "./logs/insights-service-stdout.log",
        pid_file: "./logs/insights-service.pid",
    }]
}
